import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import ErrorBoundary from './components/ErrorBoundary';
import SEOHead from './components/SEOHead';
import { performanceOptimizer } from './utils/performanceOptimizer';
import { seoOptimizer } from './utils/seoOptimizer';

// Register GSAP plugins
gsap.registerPlugin(useGSAP, ScrollTrigger);

// Components
import LoadingFlow from './components/LoadingFlow';
import Header from './components/Header';
import Hero from './components/Hero';
import LogoGenerator from './components/LogoGenerator';
import SocialMediaTools from './components/SocialMediaTools';
import BusinessTemplates from './components/BusinessTemplates';
import Footer from './components/Footer';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Initialize performance optimizations
    performanceOptimizer.addResourceHints();
    performanceOptimizer.optimizeGSAPAnimations();
    performanceOptimizer.registerServiceWorker();
    
    // Update SEO for homepage
    seoOptimizer.updatePageMeta({
      title: 'Lotaya AI - Turn Every Thought Into Design',
      description: 'Transform ideas into professional logos and brand designs instantly using cutting-edge AI technology',
      keywords: ['AI logo generator', 'design tools', 'brand design', 'Myanmar design studio', 'professional logos'],
      canonicalUrl: 'https://lotaya.io'
    });
  }, []);

  useGSAP(() => {
    // Set up smooth scrolling and scroll triggers
    ScrollTrigger.create({
      trigger: "body",
      start: "top top",
      end: "bottom bottom",
      scrub: true,
      onUpdate: (self) => {
        // Update scroll-based animations
        const progress = self.progress;
        gsap.to(".scroll-indicator", {
          scaleY: progress,
          duration: 0.1,
          ease: "none"
        });
      }
    });

    // Parallax effect for background elements
    gsap.to(".parallax-bg", {
      yPercent: -50,
      ease: "none",
      scrollTrigger: {
        trigger: ".parallax-bg",
        start: "top bottom",
        end: "bottom top",
        scrub: true
      }
    });

    // Fade in sections on scroll
    gsap.utils.toArray('.fade-in-section').forEach((section: any) => {
      gsap.fromTo(section, 
        { opacity: 0, y: 100 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: section,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );
    });
  }, []);

  const handleLoadingComplete = () => {
    setIsLoading(false);
    
    // Start main app animations after loading
    gsap.fromTo('body', 
      { opacity: 0 },
      { opacity: 1, duration: 1, ease: "power3.out" }
    );
  };

  useEffect(() => {
    // Prevent scrolling during loading
    if (isLoading) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }

    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isLoading]);

  return (
    <ErrorBoundary>
      <SEOHead
        title="Lotaya AI - Turn Every Thought Into Design"
        description="Transform ideas into professional logos and brand designs instantly using cutting-edge AI technology"
        keywords={['AI logo generator', 'design tools', 'brand design', 'Myanmar design studio', 'professional logos']}
        canonicalUrl="https://lotaya.io"
      />
      <div className="min-h-screen bg-[#0B0F19] text-white font-['Inter',sans-serif] overflow-x-hidden">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <LoadingFlow key="loading" onComplete={handleLoadingComplete} />
          ) : (
            <div key="app">
              {/* Scroll Progress Indicator */}
              <div className="fixed top-0 left-0 w-full h-1 bg-gray-800 z-50">
                <div className="scroll-indicator h-full bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] origin-left scale-y-0" />
              </div>

              {/* Header */}
              <Header />

              {/* Main Content */}
              <main>
                {/* Hero Section */}
                <div className="fade-in-section">
                  <Hero />
                </div>

                {/* Logo Generator Section */}
                <div className="fade-in-section">
                  <LogoGenerator />
                </div>

                {/* Social Media Tools Section */}
                <div className="fade-in-section">
                  <SocialMediaTools />
                </div>

                {/* Business Templates Section */}
                <div className="fade-in-section">
                  <BusinessTemplates />
                </div>
              </main>

              {/* Footer */}
              <div className="fade-in-section">
                <Footer />
              </div>

              {/* Background Parallax Elements */}
              <div className="parallax-bg fixed inset-0 pointer-events-none opacity-5 z-0">
                <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] rounded-full blur-3xl" />
                <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-to-l from-[#D3D3D3] to-[#C0C0C0] rounded-full blur-3xl" />
              </div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </ErrorBoundary>
  );
}

export default App;