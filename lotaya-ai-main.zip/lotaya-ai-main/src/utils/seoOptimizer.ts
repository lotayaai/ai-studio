// SEO Optimization utilities for Lotaya AI Platform
import { seoAPI } from './apiClient';

export interface SEOMetaData {
  title: string;
  description: string;
  keywords: string[];
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  ogUrl?: string;
  twitterCard?: string;
  twitterTitle?: string;
  twitterDescription?: string;
  twitterImage?: string;
  canonicalUrl?: string;
  schemaMarkup?: any;
}

export interface PageSEOConfig {
  path: string;
  title: string;
  description: string;
  keywords: string[];
  priority: number;
  changeFreq: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
}

class SEOOptimizer {
  private static instance: SEOOptimizer;
  private baseUrl = 'https://lotaya.io';
  private siteName = 'Lotaya AI';
  private defaultImage = 'https://lotaya.io/og-image.jpg';

  private constructor() {}

  public static getInstance(): SEOOptimizer {
    if (!SEOOptimizer.instance) {
      SEOOptimizer.instance = new SEOOptimizer();
    }
    return SEOOptimizer.instance;
  }

  // Generate comprehensive meta tags for a page
  public generateMetaTags(config: Partial<SEOMetaData>): string {
    const meta = this.buildMetaData(config);
    
    return `
      <!-- Primary Meta Tags -->
      <title>${meta.title}</title>
      <meta name="title" content="${meta.title}" />
      <meta name="description" content="${meta.description}" />
      <meta name="keywords" content="${meta.keywords.join(', ')}" />
      <meta name="robots" content="index, follow" />
      <meta name="language" content="en" />
      <meta name="author" content="Lotaya AI" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      ${meta.canonicalUrl ? `<link rel="canonical" href="${meta.canonicalUrl}" />` : ''}
      
      <!-- Open Graph / Facebook -->
      <meta property="og:type" content="website" />
      <meta property="og:url" content="${meta.ogUrl || this.baseUrl}" />
      <meta property="og:title" content="${meta.ogTitle || meta.title}" />
      <meta property="og:description" content="${meta.ogDescription || meta.description}" />
      <meta property="og:image" content="${meta.ogImage || this.defaultImage}" />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:site_name" content="${this.siteName}" />
      <meta property="og:locale" content="en_US" />
      
      <!-- Twitter -->
      <meta property="twitter:card" content="${meta.twitterCard || 'summary_large_image'}" />
      <meta property="twitter:url" content="${meta.ogUrl || this.baseUrl}" />
      <meta property="twitter:title" content="${meta.twitterTitle || meta.title}" />
      <meta property="twitter:description" content="${meta.twitterDescription || meta.description}" />
      <meta property="twitter:image" content="${meta.twitterImage || meta.ogImage || this.defaultImage}" />
      <meta property="twitter:site" content="@LotayaAI" />
      <meta property="twitter:creator" content="@LotayaAI" />
      
      <!-- Additional SEO -->
      <meta name="theme-color" content="#C0C0C0" />
      <meta name="msapplication-TileColor" content="#C0C0C0" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      
      ${meta.schemaMarkup ? `<script type="application/ld+json">${JSON.stringify(meta.schemaMarkup, null, 2)}</script>` : ''}
    `.trim();
  }

  // Build complete meta data object
  private buildMetaData(config: Partial<SEOMetaData>): SEOMetaData {
    return {
      title: config.title || `${this.siteName} - Turn Every Thought Into Design`,
      description: config.description || 'Transform ideas into professional logos and brand designs instantly using cutting-edge AI technology',
      keywords: config.keywords || ['AI logo generator', 'design tools', 'brand design', 'social media design', 'business templates'],
      ogTitle: config.ogTitle,
      ogDescription: config.ogDescription,
      ogImage: config.ogImage,
      ogUrl: config.ogUrl,
      twitterCard: config.twitterCard || 'summary_large_image',
      twitterTitle: config.twitterTitle,
      twitterDescription: config.twitterDescription,
      twitterImage: config.twitterImage,
      canonicalUrl: config.canonicalUrl,
      schemaMarkup: config.schemaMarkup || this.generateDefaultSchema()
    };
  }

  // Generate default schema markup
  private generateDefaultSchema() {
    return {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "Lotaya AI",
      "alternateName": "Lotaya",
      "url": this.baseUrl,
      "logo": `${this.baseUrl}/logo.png`,
      "image": this.defaultImage,
      "email": "info@lotaya.io",
      "telephone": "09970000616",
      "foundingDate": "2025",
      "slogan": "Turn every thought into design",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Yangon",
        "addressRegion": "Yangon Region",
        "addressCountry": "Myanmar"
      },
      "description": "AI-powered design studio that transforms ideas into professional logos and brand designs instantly",
      "sameAs": [
        "https://facebook.com/LotayaAI",
        "https://twitter.com/LotayaAI",
        "https://instagram.com/LotayaAI",
        "https://linkedin.com/company/lotaya-ai"
      ],
      "serviceType": "AI Design Services",
      "areaServed": "Worldwide"
    };
  }

  // Generate sitemap XML
  public generateSitemap(pages: PageSEOConfig[]): string {
    const urls = pages.map(page => `
      <url>
        <loc>${this.baseUrl}${page.path}</loc>
        <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
        <changefreq>${page.changeFreq}</changefreq>
        <priority>${page.priority}</priority>
      </url>
    `).join('');

    return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${urls}
</urlset>`;
  }

  // Update page meta tags dynamically
  public updatePageMeta(metaData: Partial<SEOMetaData>): void {
    const meta = this.buildMetaData(metaData);
    
    // Update title
    document.title = meta.title;
    
    // Update meta tags
    this.updateMetaTag('name', 'description', meta.description);
    this.updateMetaTag('name', 'keywords', meta.keywords.join(', '));
    this.updateMetaTag('property', 'og:title', meta.ogTitle || meta.title);
    this.updateMetaTag('property', 'og:description', meta.ogDescription || meta.description);
    this.updateMetaTag('property', 'og:image', meta.ogImage || this.defaultImage);
    this.updateMetaTag('property', 'og:url', meta.ogUrl || window.location.href);
    this.updateMetaTag('property', 'twitter:title', meta.twitterTitle || meta.title);
    this.updateMetaTag('property', 'twitter:description', meta.twitterDescription || meta.description);
    this.updateMetaTag('property', 'twitter:image', meta.twitterImage || meta.ogImage || this.defaultImage);
    
    // Update canonical URL
    if (meta.canonicalUrl) {
      this.updateCanonicalUrl(meta.canonicalUrl);
    }
  }

  private updateMetaTag(attribute: string, name: string, content: string): void {
    let element = document.querySelector(`meta[${attribute}="${name}"]`) as HTMLMetaElement;
    
    if (!element) {
      element = document.createElement('meta');
      element.setAttribute(attribute, name);
      document.head.appendChild(element);
    }
    
    element.content = content;
  }

  private updateCanonicalUrl(url: string): void {
    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    
    canonical.href = url;
  }

  // Analyze content for SEO optimization
  public async analyzeContent(content: string): Promise<any> {
    try {
      const response = await seoAPI.analyzeContent(content);
      return response.data;
    } catch (error) {
      console.error('SEO content analysis failed:', error);
      return null;
    }
  }

  // Get keyword suggestions
  public async getKeywordSuggestions(topic: string): Promise<string[]> {
    try {
      const response = await seoAPI.getKeywords(topic);
      return response.data.keywords || [];
    } catch (error) {
      console.error('Keyword suggestions failed:', error);
      return [];
    }
  }
}

// Export singleton instance
export const seoOptimizer = SEOOptimizer.getInstance();

// Page configurations for sitemap
export const pageConfigs: PageSEOConfig[] = [
  {
    path: '/',
    title: 'Lotaya AI - Turn Every Thought Into Design',
    description: 'Transform ideas into professional logos and brand designs instantly using cutting-edge AI technology',
    keywords: ['AI logo generator', 'design tools', 'brand design', 'Myanmar design studio'],
    priority: 1.0,
    changeFreq: 'daily'
  },
  {
    path: '/logo-generator',
    title: 'AI Logo Generator - Create Professional Logos Instantly',
    description: 'Generate unique, professional logos for your business using advanced AI technology. Turn your ideas into stunning brand designs.',
    keywords: ['AI logo generator', 'logo design', 'business logos', 'brand identity'],
    priority: 0.9,
    changeFreq: 'weekly'
  },
  {
    path: '/social-media-tools',
    title: 'Social Media Design Tools - Create Content for All Platforms',
    description: 'Design professional social media content for Instagram, Facebook, Twitter, and more with perfect dimensions and stunning designs.',
    keywords: ['social media design', 'Instagram posts', 'Facebook covers', 'social content'],
    priority: 0.9,
    changeFreq: 'weekly'
  },
  {
    path: '/business-templates',
    title: 'Business Templates - Professional Marketing Materials',
    description: 'Create business cards, letterheads, flyers, and marketing materials with AI-powered design templates.',
    keywords: ['business templates', 'business cards', 'marketing materials', 'professional design'],
    priority: 0.9,
    changeFreq: 'weekly'
  },
  {
    path: '/pricing',
    title: 'Pricing Plans - Affordable AI Design Solutions',
    description: 'Choose the perfect plan for your design needs. Affordable pricing for individuals, businesses, and enterprises.',
    keywords: ['pricing', 'design plans', 'affordable design', 'subscription'],
    priority: 0.8,
    changeFreq: 'monthly'
  },
  {
    path: '/about',
    title: 'About Lotaya AI - Myanmar\'s Leading AI Design Studio',
    description: 'Learn about Lotaya AI, Myanmar\'s premier AI-powered design studio transforming ideas into professional designs.',
    keywords: ['about Lotaya AI', 'Myanmar design studio', 'AI design company'],
    priority: 0.7,
    changeFreq: 'monthly'
  },
  {
    path: '/contact',
    title: 'Contact Us - Get in Touch with Lotaya AI',
    description: 'Contact Lotaya AI for support, partnerships, or custom design solutions. We\'re here to help turn your thoughts into designs.',
    keywords: ['contact', 'support', 'Lotaya AI contact', 'design support'],
    priority: 0.7,
    changeFreq: 'monthly'
  }
];