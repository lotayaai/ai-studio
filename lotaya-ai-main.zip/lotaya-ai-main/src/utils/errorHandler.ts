// Global error handling utilities for Lotaya AI

export interface ErrorInfo {
  message: string;
  stack?: string;
  componentStack?: string;
  timestamp: Date;
  userAgent: string;
  url: string;
  userId?: string;
}

export class ErrorLogger {
  private static instance: ErrorLogger;
  private errors: ErrorInfo[] = [];

  private constructor() {
    this.setupGlobalErrorHandlers();
  }

  public static getInstance(): ErrorLogger {
    if (!ErrorLogger.instance) {
      ErrorLogger.instance = new ErrorLogger();
    }
    return ErrorLogger.instance;
  }

  private setupGlobalErrorHandlers(): void {
    // Handle unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      this.logError({
        message: `Unhandled Promise Rejection: ${event.reason}`,
        stack: event.reason?.stack,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
    });

    // Handle global JavaScript errors
    window.addEventListener('error', (event) => {
      this.logError({
        message: event.message,
        stack: event.error?.stack,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
    });

    // Handle resource loading errors
    window.addEventListener('error', (event) => {
      if (event.target !== window) {
        this.logError({
          message: `Resource loading error: ${(event.target as any)?.src || (event.target as any)?.href}`,
          timestamp: new Date(),
          userAgent: navigator.userAgent,
          url: window.location.href
        });
      }
    }, true);
  }

  public logError(errorInfo: Partial<ErrorInfo>): void {
    const fullErrorInfo: ErrorInfo = {
      message: errorInfo.message || 'Unknown error',
      stack: errorInfo.stack,
      componentStack: errorInfo.componentStack,
      timestamp: errorInfo.timestamp || new Date(),
      userAgent: errorInfo.userAgent || navigator.userAgent,
      url: errorInfo.url || window.location.href,
      userId: errorInfo.userId
    };

    this.errors.push(fullErrorInfo);

    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.error('Lotaya AI Error:', fullErrorInfo);
    }

    // In production, you would send this to your error tracking service
    // Example: Sentry, LogRocket, or Google Cloud Error Reporting
    this.sendToErrorService(fullErrorInfo);
  }

  private async sendToErrorService(errorInfo: ErrorInfo): Promise<void> {
    try {
      // In a real implementation, you would send to your error tracking service
      // For now, we'll just store it locally
      const errors = this.getStoredErrors();
      errors.push(errorInfo);
      
      // Keep only the last 50 errors to prevent storage bloat
      const recentErrors = errors.slice(-50);
      localStorage.setItem('lotaya_errors', JSON.stringify(recentErrors));
    } catch (error) {
      console.error('Failed to store error:', error);
    }
  }

  public getStoredErrors(): ErrorInfo[] {
    try {
      const stored = localStorage.getItem('lotaya_errors');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  public clearStoredErrors(): void {
    localStorage.removeItem('lotaya_errors');
    this.errors = [];
  }

  public getRecentErrors(count: number = 10): ErrorInfo[] {
    return this.errors.slice(-count);
  }
}

// Performance monitoring utilities
export class PerformanceMonitor {
  private static instance: PerformanceMonitor;
  private metrics: Map<string, number> = new Map();

  private constructor() {
    this.setupPerformanceObserver();
  }

  public static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor();
    }
    return PerformanceMonitor.instance;
  }

  private setupPerformanceObserver(): void {
    if ('PerformanceObserver' in window) {
      // Monitor Core Web Vitals
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          this.recordMetric(entry.name, entry.value);
        }
      });

      try {
        observer.observe({ entryTypes: ['measure', 'navigation', 'paint'] });
      } catch (error) {
        console.warn('Performance Observer not supported:', error);
      }
    }
  }

  public recordMetric(name: string, value: number): void {
    this.metrics.set(name, value);
    
    // Log performance issues in development
    if (process.env.NODE_ENV === 'development') {
      if (name === 'first-contentful-paint' && value > 2000) {
        console.warn(`Slow FCP detected: ${value}ms`);
      }
      if (name === 'largest-contentful-paint' && value > 2500) {
        console.warn(`Slow LCP detected: ${value}ms`);
      }
    }
  }

  public getMetrics(): Map<string, number> {
    return new Map(this.metrics);
  }

  public getMetric(name: string): number | undefined {
    return this.metrics.get(name);
  }
}

// Network error handling
export class NetworkErrorHandler {
  public static handleFetchError(error: Error, url: string): void {
    const errorLogger = ErrorLogger.getInstance();
    
    errorLogger.logError({
      message: `Network request failed: ${error.message}`,
      stack: error.stack,
      timestamp: new Date(),
      userAgent: navigator.userAgent,
      url: url
    });

    // Check if it's a network connectivity issue
    if (!navigator.onLine) {
      this.showOfflineMessage();
    }
  }

  private static showOfflineMessage(): void {
    // Create a simple offline notification
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #ef4444;
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      z-index: 10000;
      font-family: Inter, sans-serif;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    `;
    notification.textContent = 'You appear to be offline. Please check your connection.';
    
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 5000);
  }
}

// Initialize error handling
export const initializeErrorHandling = (): void => {
  ErrorLogger.getInstance();
  PerformanceMonitor.getInstance();
  
  // Set up network status monitoring
  window.addEventListener('online', () => {
    console.log('Connection restored');
  });
  
  window.addEventListener('offline', () => {
    console.log('Connection lost');
    NetworkErrorHandler['showOfflineMessage']();
  });
};

// Export singleton instances
export const errorLogger = ErrorLogger.getInstance();
export const performanceMonitor = PerformanceMonitor.getInstance();