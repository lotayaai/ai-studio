// Google API Client for Lotaya AI Platform
import { errorLogger } from './errorHandler';

export interface GoogleApiConfig {
  apiKey: string;
  timeout: number;
  retries: number;
}

export interface GoogleApiResponse<T = any> {
  data: T;
  status: number;
  message?: string;
  error?: string;
}

class GoogleApiClient {
  private config: GoogleApiConfig;
  private baseUrl = 'https://googleapis.com';

  constructor(config: GoogleApiConfig) {
    this.config = config;
  }

  private async makeRequest<T>(
    endpoint: string,
    options: RequestInit = {},
    retryCount = 0
  ): Promise<GoogleApiResponse<T>> {
    const url = `${this.baseUrl}${endpoint}`;
    const apiKey = this.config.apiKey;
    
    // Add API key to URL
    const separator = endpoint.includes('?') ? '&' : '?';
    const urlWithKey = `${url}${separator}key=${apiKey}`;

    const defaultHeaders: HeadersInit = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'User-Agent': 'Lotaya-AI/1.0',
    };

    const requestOptions: RequestInit = {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers,
      },
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

    try {
      const response = await fetch(urlWithKey, {
        ...requestOptions,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`Google API Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      return {
        data,
        status: response.status,
        message: 'Success'
      };

    } catch (error) {
      clearTimeout(timeoutId);
      
      if (error instanceof Error) {
        errorLogger.logError({
          message: `Google API request failed: ${error.message}`,
          stack: error.stack,
          timestamp: new Date(),
          userAgent: navigator.userAgent,
          url: urlWithKey
        });
        
        // Retry logic for network errors
        if (retryCount < this.config.retries && 
            (error.name === 'AbortError' || error.message.includes('fetch'))) {
          
          await new Promise(resolve => 
            setTimeout(resolve, 1000 * Math.pow(2, retryCount))
          );
          
          return this.makeRequest<T>(endpoint, options, retryCount + 1);
        }
      }

      throw error;
    }
  }

  // Google Fonts API
  async getFonts(sort: string = 'popularity'): Promise<GoogleApiResponse> {
    return this.makeRequest(`/webfonts/v1/webfonts?sort=${sort}`);
  }

  // Google Custom Search API (for design inspiration)
  async searchImages(query: string, searchType: string = 'image'): Promise<GoogleApiResponse> {
    const cx = 'your-custom-search-engine-id'; // You'll need to set this up
    return this.makeRequest(
      `/customsearch/v1?q=${encodeURIComponent(query)}&searchType=${searchType}&cx=${cx}`
    );
  }

  // Google Cloud Vision API (for image analysis)
  async analyzeImage(imageBase64: string): Promise<GoogleApiResponse> {
    return this.makeRequest('/v1/images:annotate', {
      method: 'POST',
      body: JSON.stringify({
        requests: [{
          image: {
            content: imageBase64
          },
          features: [
            { type: 'LABEL_DETECTION', maxResults: 10 },
            { type: 'COLOR_PROPERTIES' },
            { type: 'IMAGE_PROPERTIES' }
          ]
        }]
      })
    });
  }

  // Google Translate API (for multi-language support)
  async translateText(text: string, targetLanguage: string): Promise<GoogleApiResponse> {
    return this.makeRequest('/language/translate/v2', {
      method: 'POST',
      body: JSON.stringify({
        q: text,
        target: targetLanguage,
        format: 'text'
      })
    });
  }

  // Google Places API (for business information)
  async searchPlaces(query: string): Promise<GoogleApiResponse> {
    return this.makeRequest(
      `/maps/api/place/textsearch/json?query=${encodeURIComponent(query)}`
    );
  }
}

// Google API Configuration
const googleApiConfig: GoogleApiConfig = {
  apiKey: import.meta.env.VITE_GOOGLE_API_KEY || '',
  timeout: 10000, // 10 seconds
  retries: 3,
};

// Export singleton instance
export const googleApiClient = new GoogleApiClient(googleApiConfig);

// Specific Google API endpoints
export const googleFontsAPI = {
  getFonts: (sort?: string) => googleApiClient.getFonts(sort),
  getFontDetails: (family: string) => 
    googleApiClient.makeRequest(`/webfonts/v1/webfonts?family=${encodeURIComponent(family)}`),
};

export const googleVisionAPI = {
  analyzeImage: (imageBase64: string) => googleApiClient.analyzeImage(imageBase64),
  detectText: (imageBase64: string) => 
    googleApiClient.makeRequest('/v1/images:annotate', {
      method: 'POST',
      body: JSON.stringify({
        requests: [{
          image: { content: imageBase64 },
          features: [{ type: 'TEXT_DETECTION' }]
        }]
      })
    }),
};

export const googleTranslateAPI = {
  translate: (text: string, target: string) => 
    googleApiClient.translateText(text, target),
  detectLanguage: (text: string) =>
    googleApiClient.makeRequest('/language/translate/v2/detect', {
      method: 'POST',
      body: JSON.stringify({ q: text })
    }),
};

export const googlePlacesAPI = {
  searchPlaces: (query: string) => googleApiClient.searchPlaces(query),
  getPlaceDetails: (placeId: string) =>
    googleApiClient.makeRequest(
      `/maps/api/place/details/json?place_id=${placeId}`
    ),
};