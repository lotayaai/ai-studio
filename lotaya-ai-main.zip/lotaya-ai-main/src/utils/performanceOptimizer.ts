// Performance optimization utilities for Lotaya AI Platform
import { performanceMonitor } from './errorHandler';

export class PerformanceOptimizer {
  private static instance: PerformanceOptimizer;
  private imageCache = new Map<string, HTMLImageElement>();
  private fontCache = new Set<string>();

  private constructor() {
    this.initializeOptimizations();
  }

  public static getInstance(): PerformanceOptimizer {
    if (!PerformanceOptimizer.instance) {
      PerformanceOptimizer.instance = new PerformanceOptimizer();
    }
    return PerformanceOptimizer.instance;
  }

  private initializeOptimizations(): void {
    // Preload critical fonts
    this.preloadFonts([
      'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap'
    ]);

    // Set up intersection observer for lazy loading
    this.setupLazyLoading();

    // Monitor Core Web Vitals
    this.monitorWebVitals();
  }

  // Preload critical fonts
  private preloadFonts(fontUrls: string[]): void {
    fontUrls.forEach(url => {
      if (!this.fontCache.has(url)) {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'style';
        link.href = url;
        document.head.appendChild(link);
        
        // Also add the actual stylesheet
        const stylesheet = document.createElement('link');
        stylesheet.rel = 'stylesheet';
        stylesheet.href = url;
        document.head.appendChild(stylesheet);
        
        this.fontCache.add(url);
      }
    });
  }

  // Preload critical images
  public preloadImages(imageUrls: string[]): Promise<void[]> {
    const promises = imageUrls.map(url => this.preloadImage(url));
    return Promise.all(promises);
  }

  private preloadImage(url: string): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.imageCache.has(url)) {
        resolve();
        return;
      }

      const img = new Image();
      img.onload = () => {
        this.imageCache.set(url, img);
        resolve();
      };
      img.onerror = reject;
      img.src = url;
    });
  }

  // Set up lazy loading for images
  private setupLazyLoading(): void {
    if ('IntersectionObserver' in window) {
      const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const img = entry.target as HTMLImageElement;
            const src = img.dataset.src;
            
            if (src) {
              img.src = src;
              img.removeAttribute('data-src');
              imageObserver.unobserve(img);
            }
          }
        });
      }, {
        rootMargin: '50px 0px',
        threshold: 0.01
      });

      // Observe all images with data-src attribute
      document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
      });
    }
  }

  // Monitor Core Web Vitals
  private monitorWebVitals(): void {
    // First Contentful Paint (FCP)
    this.measureFCP();
    
    // Largest Contentful Paint (LCP)
    this.measureLCP();
    
    // Cumulative Layout Shift (CLS)
    this.measureCLS();
    
    // First Input Delay (FID)
    this.measureFID();
  }

  private measureFCP(): void {
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.name === 'first-contentful-paint') {
          performanceMonitor.recordMetric('FCP', entry.startTime);
          console.log('FCP:', entry.startTime);
        }
      }
    });
    
    try {
      observer.observe({ entryTypes: ['paint'] });
    } catch (e) {
      console.warn('FCP measurement not supported');
    }
  }

  private measureLCP(): void {
    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1];
      performanceMonitor.recordMetric('LCP', lastEntry.startTime);
      console.log('LCP:', lastEntry.startTime);
    });
    
    try {
      observer.observe({ entryTypes: ['largest-contentful-paint'] });
    } catch (e) {
      console.warn('LCP measurement not supported');
    }
  }

  private measureCLS(): void {
    let clsValue = 0;
    let clsEntries: any[] = [];

    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!(entry as any).hadRecentInput) {
          const firstSessionEntry = clsEntries[0];
          const lastSessionEntry = clsEntries[clsEntries.length - 1];

          if (!firstSessionEntry || 
              entry.startTime - lastSessionEntry.startTime < 1000 &&
              entry.startTime - firstSessionEntry.startTime < 5000) {
            clsEntries.push(entry);
            clsValue += (entry as any).value;
          } else {
            clsEntries = [entry];
            clsValue = (entry as any).value;
          }
        }
      }
      
      performanceMonitor.recordMetric('CLS', clsValue);
      console.log('CLS:', clsValue);
    });

    try {
      observer.observe({ entryTypes: ['layout-shift'] });
    } catch (e) {
      console.warn('CLS measurement not supported');
    }
  }

  private measureFID(): void {
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        performanceMonitor.recordMetric('FID', (entry as any).processingStart - entry.startTime);
        console.log('FID:', (entry as any).processingStart - entry.startTime);
      }
    });

    try {
      observer.observe({ entryTypes: ['first-input'] });
    } catch (e) {
      console.warn('FID measurement not supported');
    }
  }

  // Optimize GSAP animations for performance
  public optimizeGSAPAnimations(): void {
    // Set GSAP to use CSS transforms for better performance
    if (typeof gsap !== 'undefined') {
      gsap.config({
        force3D: true,
        nullTargetWarn: false,
      });

      // Use will-change CSS property for animated elements
      gsap.set('.gsap-animated', { willChange: 'transform' });
    }
  }

  // Debounce function for performance-critical operations
  public debounce<T extends (...args: any[]) => any>(
    func: T,
    wait: number
  ): (...args: Parameters<T>) => void {
    let timeout: NodeJS.Timeout;
    
    return (...args: Parameters<T>) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => func.apply(this, args), wait);
    };
  }

  // Throttle function for scroll and resize events
  public throttle<T extends (...args: any[]) => any>(
    func: T,
    limit: number
  ): (...args: Parameters<T>) => void {
    let inThrottle: boolean;
    
    return (...args: Parameters<T>) => {
      if (!inThrottle) {
        func.apply(this, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }

  // Resource hints for better loading performance
  public addResourceHints(): void {
    const hints = [
      { rel: 'dns-prefetch', href: '//fonts.googleapis.com' },
      { rel: 'dns-prefetch', href: '//fonts.gstatic.com' },
      { rel: 'preconnect', href: 'https://api.lotaya.io' },
    ];

    hints.forEach(hint => {
      const link = document.createElement('link');
      link.rel = hint.rel;
      link.href = hint.href;
      document.head.appendChild(link);
    });
  }

  // Critical CSS inlining
  public inlineCriticalCSS(css: string): void {
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
  }

  // Service Worker registration for caching
  public registerServiceWorker(): void {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
          .then(registration => {
            console.log('SW registered: ', registration);
          })
          .catch(registrationError => {
            console.log('SW registration failed: ', registrationError);
          });
      });
    }
  }
}

// Export singleton instance
export const performanceOptimizer = PerformanceOptimizer.getInstance();