// Google Cloud Storage integration for Lotaya AI Platform
import { Storage } from '@google-cloud/storage';
import { errorLogger } from './errorHandler';

export interface UploadOptions {
  bucket: string;
  fileName: string;
  contentType?: string;
  metadata?: Record<string, string>;
  makePublic?: boolean;
}

export interface DownloadOptions {
  bucket: string;
  fileName: string;
}

class CloudStorageClient {
  private storage: Storage;
  private projectId: string;

  constructor() {
    this.projectId = import.meta.env.VITE_GOOGLE_CLOUD_PROJECT || 'lotaya-ai';
    
    // Initialize Google Cloud Storage
    this.storage = new Storage({
      projectId: this.projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS, // For server-side
    });
  }

  // Upload file to Google Cloud Storage
  async uploadFile(file: File, options: UploadOptions): Promise<string> {
    try {
      const bucket = this.storage.bucket(options.bucket);
      const fileUpload = bucket.file(options.fileName);

      // Convert File to Buffer for upload
      const arrayBuffer = await file.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);

      const stream = fileUpload.createWriteStream({
        metadata: {
          contentType: options.contentType || file.type,
          metadata: options.metadata || {},
        },
        resumable: false,
      });

      return new Promise((resolve, reject) => {
        stream.on('error', (error) => {
          errorLogger.logError({
            message: `Cloud Storage upload failed: ${error.message}`,
            stack: error.stack,
            timestamp: new Date(),
            userAgent: navigator.userAgent,
            url: window.location.href
          });
          reject(error);
        });

        stream.on('finish', async () => {
          try {
            if (options.makePublic) {
              await fileUpload.makePublic();
            }
            
            const publicUrl = `https://storage.googleapis.com/${options.bucket}/${options.fileName}`;
            resolve(publicUrl);
          } catch (error) {
            reject(error);
          }
        });

        stream.end(buffer);
      });
    } catch (error) {
      errorLogger.logError({
        message: `Cloud Storage upload error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      throw error;
    }
  }

  // Download file from Google Cloud Storage
  async downloadFile(options: DownloadOptions): Promise<Buffer> {
    try {
      const bucket = this.storage.bucket(options.bucket);
      const file = bucket.file(options.fileName);

      const [buffer] = await file.download();
      return buffer;
    } catch (error) {
      errorLogger.logError({
        message: `Cloud Storage download error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      throw error;
    }
  }

  // Get signed URL for temporary access
  async getSignedUrl(options: DownloadOptions, expirationMinutes: number = 60): Promise<string> {
    try {
      const bucket = this.storage.bucket(options.bucket);
      const file = bucket.file(options.fileName);

      const [signedUrl] = await file.getSignedUrl({
        action: 'read',
        expires: Date.now() + expirationMinutes * 60 * 1000,
      });

      return signedUrl;
    } catch (error) {
      errorLogger.logError({
        message: `Signed URL generation error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      throw error;
    }
  }

  // List files in bucket
  async listFiles(bucketName: string, prefix?: string): Promise<string[]> {
    try {
      const bucket = this.storage.bucket(bucketName);
      const [files] = await bucket.getFiles({ prefix });
      
      return files.map(file => file.name);
    } catch (error) {
      errorLogger.logError({
        message: `List files error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      throw error;
    }
  }

  // Delete file from bucket
  async deleteFile(options: DownloadOptions): Promise<void> {
    try {
      const bucket = this.storage.bucket(options.bucket);
      const file = bucket.file(options.fileName);

      await file.delete();
    } catch (error) {
      errorLogger.logError({
        message: `File deletion error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      throw error;
    }
  }

  // Create bucket if it doesn't exist
  async createBucket(bucketName: string, location: string = 'US'): Promise<void> {
    try {
      const [bucket] = await this.storage.createBucket(bucketName, {
        location,
        storageClass: 'STANDARD',
      });

      console.log(`Bucket ${bucket.name} created.`);
    } catch (error) {
      if (error instanceof Error && error.message.includes('already exists')) {
        console.log(`Bucket ${bucketName} already exists.`);
        return;
      }
      
      errorLogger.logError({
        message: `Bucket creation error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      throw error;
    }
  }
}

// Export singleton instance
export const cloudStorage = new CloudStorageClient();

// Predefined bucket configurations for Lotaya AI
export const LOTAYA_BUCKETS = {
  LOGOS: 'lotaya-logos',
  TEMPLATES: 'lotaya-templates',
  USER_UPLOADS: 'lotaya-user-uploads',
  SOCIAL_MEDIA: 'lotaya-social-media',
  ASSETS: 'lotaya-assets',
} as const;

// Helper functions for common operations
export const logoStorage = {
  upload: (file: File, logoId: string) => 
    cloudStorage.uploadFile(file, {
      bucket: LOTAYA_BUCKETS.LOGOS,
      fileName: `${logoId}/${file.name}`,
      makePublic: true,
      metadata: {
        logoId,
        uploadedAt: new Date().toISOString(),
      }
    }),
  
  download: (logoId: string, fileName: string) =>
    cloudStorage.downloadFile({
      bucket: LOTAYA_BUCKETS.LOGOS,
      fileName: `${logoId}/${fileName}`
    }),
};

export const templateStorage = {
  upload: (file: File, templateId: string) =>
    cloudStorage.uploadFile(file, {
      bucket: LOTAYA_BUCKETS.TEMPLATES,
      fileName: `${templateId}/${file.name}`,
      makePublic: true,
      metadata: {
        templateId,
        uploadedAt: new Date().toISOString(),
      }
    }),
  
  list: (templateId?: string) =>
    cloudStorage.listFiles(LOTAYA_BUCKETS.TEMPLATES, templateId),
};

export const userUploadStorage = {
  upload: (file: File, userId: string) =>
    cloudStorage.uploadFile(file, {
      bucket: LOTAYA_BUCKETS.USER_UPLOADS,
      fileName: `${userId}/${Date.now()}-${file.name}`,
      makePublic: false,
      metadata: {
        userId,
        originalName: file.name,
        uploadedAt: new Date().toISOString(),
      }
    }),
  
  getSignedUrl: (userId: string, fileName: string) =>
    cloudStorage.getSignedUrl({
      bucket: LOTAYA_BUCKETS.USER_UPLOADS,
      fileName: `${userId}/${fileName}`
    }),
};