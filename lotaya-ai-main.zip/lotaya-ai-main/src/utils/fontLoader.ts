// Font loading optimization for Lotaya AI Platform
export class FontLoader {
  private static instance: FontLoader;
  private loadedFonts = new Set<string>();
  private fontObserver: FontFaceObserver | null = null;

  private constructor() {
    this.initializeFontLoading();
  }

  public static getInstance(): FontLoader {
    if (!FontLoader.instance) {
      FontLoader.instance = new FontLoader();
    }
    return FontLoader.instance;
  }

  private initializeFontLoading(): void {
    // Preload critical fonts
    this.preloadFont('Inter', [300, 400, 500, 600, 700]);
    
    // Set up font display optimization
    this.optimizeFontDisplay();
  }

  private preloadFont(family: string, weights: number[]): void {
    weights.forEach(weight => {
      const fontKey = `${family}-${weight}`;
      
      if (!this.loadedFonts.has(fontKey)) {
        // Create font face
        const font = new FontFace(
          family,
          `url(https://fonts.gstatic.com/s/inter/v12/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuLyfAZ9hiA.woff2) format('woff2')`,
          {
            weight: weight.toString(),
            style: 'normal',
            display: 'swap'
          }
        );

        // Load and add to document
        font.load().then(() => {
          document.fonts.add(font);
          this.loadedFonts.add(fontKey);
          console.log(`Font loaded: ${fontKey}`);
        }).catch(error => {
          console.error(`Failed to load font: ${fontKey}`, error);
        });
      }
    });
  }

  private optimizeFontDisplay(): void {
    // Add font-display: swap to existing font links
    const fontLinks = document.querySelectorAll('link[href*="fonts.googleapis.com"]');
    fontLinks.forEach(link => {
      const href = link.getAttribute('href');
      if (href && !href.includes('display=swap')) {
        const separator = href.includes('?') ? '&' : '?';
        link.setAttribute('href', `${href}${separator}display=swap`);
      }
    });
  }

  public async loadFontAsync(family: string, weight: number = 400): Promise<void> {
    const fontKey = `${family}-${weight}`;
    
    if (this.loadedFonts.has(fontKey)) {
      return Promise.resolve();
    }

    return new Promise((resolve, reject) => {
      const font = new FontFace(
        family,
        `url(https://fonts.gstatic.com/s/${family.toLowerCase()}/v12/font.woff2) format('woff2')`,
        {
          weight: weight.toString(),
          style: 'normal',
          display: 'swap'
        }
      );

      font.load()
        .then(() => {
          document.fonts.add(font);
          this.loadedFonts.add(fontKey);
          resolve();
        })
        .catch(reject);
    });
  }

  public getFontLoadStatus(): { [key: string]: boolean } {
    const status: { [key: string]: boolean } = {};
    this.loadedFonts.forEach(font => {
      status[font] = true;
    });
    return status;
  }

  public preloadCriticalFonts(): Promise<void[]> {
    const criticalFonts = [
      { family: 'Inter', weight: 400 },
      { family: 'Inter', weight: 500 },
      { family: 'Inter', weight: 600 },
      { family: 'Inter', weight: 700 }
    ];

    const promises = criticalFonts.map(font => 
      this.loadFontAsync(font.family, font.weight)
    );

    return Promise.all(promises);
  }
}

// Font Face Observer polyfill for older browsers
class FontFaceObserver {
  private family: string;
  private descriptors: any;

  constructor(family: string, descriptors: any = {}) {
    this.family = family;
    this.descriptors = descriptors;
  }

  load(text: string = 'BESbswy', timeout: number = 3000): Promise<void> {
    return new Promise((resolve, reject) => {
      const testString = text;
      const testElement = document.createElement('div');
      
      testElement.style.cssText = `
        position: absolute;
        left: -9999px;
        top: -9999px;
        font-size: 72px;
        font-family: monospace;
        visibility: hidden;
      `;
      
      testElement.textContent = testString;
      document.body.appendChild(testElement);
      
      const fallbackWidth = testElement.offsetWidth;
      
      testElement.style.fontFamily = `${this.family}, monospace`;
      
      const checkFont = () => {
        if (testElement.offsetWidth !== fallbackWidth) {
          document.body.removeChild(testElement);
          resolve();
        }
      };
      
      const timeoutId = setTimeout(() => {
        document.body.removeChild(testElement);
        reject(new Error('Font load timeout'));
      }, timeout);
      
      // Check immediately and then poll
      checkFont();
      const intervalId = setInterval(() => {
        checkFont();
        if (testElement.offsetWidth !== fallbackWidth) {
          clearInterval(intervalId);
          clearTimeout(timeoutId);
        }
      }, 50);
    });
  }
}

// Export singleton instance
export const fontLoader = FontLoader.getInstance();