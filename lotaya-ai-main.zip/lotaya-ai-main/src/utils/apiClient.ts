// API Client with comprehensive error handling and timeout configurations
import { errorLogger, NetworkErrorHandler } from './errorHandler';
import { googleApiClient } from './googleApiClient';

export interface ApiResponse<T = any> {
  data: T;
  status: number;
  message?: string;
  error?: string;
}

export interface ApiConfig {
  baseURL: string;
  timeout: number;
  retries: number;
  retryDelay: number;
}

class ApiClient {
  private config: ApiConfig;
  private authToken: string | null = null;

  constructor(config: ApiConfig) {
    this.config = config;
  }

  setAuthToken(token: string) {
    this.authToken = token;
  }

  private async makeRequest<T>(
    endpoint: string,
    options: RequestInit = {},
    retryCount = 0
  ): Promise<ApiResponse<T>> {
    const url = `${this.config.baseURL}${endpoint}`;
    
    const defaultHeaders: HeadersInit = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'User-Agent': 'Lotaya-AI/1.0',
    };

    if (this.authToken) {
      defaultHeaders['Authorization'] = `Bearer ${this.authToken}`;
    }

    const requestOptions: RequestInit = {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers,
      },
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

    try {
      const response = await fetch(url, {
        ...requestOptions,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      return {
        data,
        status: response.status,
        message: 'Success'
      };

    } catch (error) {
      clearTimeout(timeoutId);
      
      if (error instanceof Error) {
        NetworkErrorHandler.handleFetchError(error, url);
        
        // Retry logic for network errors
        if (retryCount < this.config.retries && 
            (error.name === 'AbortError' || error.message.includes('fetch'))) {
          
          await new Promise(resolve => 
            setTimeout(resolve, this.config.retryDelay * Math.pow(2, retryCount))
          );
          
          return this.makeRequest<T>(endpoint, options, retryCount + 1);
        }
      }

      throw error;
    }
  }

  async get<T>(endpoint: string, params?: Record<string, string>): Promise<ApiResponse<T>> {
    const url = params ? 
      `${endpoint}?${new URLSearchParams(params).toString()}` : 
      endpoint;
    
    return this.makeRequest<T>(url, { method: 'GET' });
  }

  async post<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    return this.makeRequest<T>(endpoint, {
      method: 'POST',
      body: data ? JSON.stringify(data) : undefined,
    });
  }

  async put<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    return this.makeRequest<T>(endpoint, {
      method: 'PUT',
      body: data ? JSON.stringify(data) : undefined,
    });
  }

  async delete<T>(endpoint: string): Promise<ApiResponse<T>> {
    return this.makeRequest<T>(endpoint, { method: 'DELETE' });
  }

  async patch<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    return this.makeRequest<T>(endpoint, {
      method: 'PATCH',
      body: data ? JSON.stringify(data) : undefined,
    });
  }
}

// API Configuration
const apiConfig: ApiConfig = {
  baseURL: process.env.NODE_ENV === 'production' 
    ? import.meta.env.VITE_API_BASE_URL || 'https://lotaya-api-dot-lotaya-ai.appspot.com/v1'
    : 'http://localhost:3001/api/v1',
  timeout: 10000, // 10 seconds
  retries: 3,
  retryDelay: 1000, // 1 second base delay
};

// Export singleton instance
export const apiClient = new ApiClient(apiConfig);

// Specific API endpoints
export const logoAPI = {
  generate: (data: any) => apiClient.post('/logos/generate', data),
  getById: (id: string) => apiClient.get(`/logos/${id}`),
  update: (id: string, data: any) => apiClient.put(`/logos/${id}`, data),
  delete: (id: string) => apiClient.delete(`/logos/${id}`),
  list: (params?: Record<string, string>) => apiClient.get('/logos', params),
};

export const socialMediaAPI = {
  generatePost: (data: any) => apiClient.post('/social-media/posts', data),
  generateStory: (data: any) => apiClient.post('/social-media/stories', data),
  getTemplates: (platform: string) => apiClient.get(`/social-media/templates/${platform}`),
  resize: (id: string, dimensions: any) => apiClient.post(`/social-media/${id}/resize`, dimensions),
};

export const businessTemplatesAPI = {
  list: (category?: string) => apiClient.get('/templates', category ? { category } : undefined),
  getById: (id: string) => apiClient.get(`/templates/${id}`),
  customize: (id: string, data: any) => apiClient.post(`/templates/${id}/customize`, data),
  download: (id: string, format: string) => apiClient.get(`/templates/${id}/download/${format}`),
};

export const authAPI = {
  login: (credentials: any) => apiClient.post('/auth/login', credentials),
  register: (userData: any) => apiClient.post('/auth/register', userData),
  refresh: (refreshToken: string) => apiClient.post('/auth/refresh', { refreshToken }),
  logout: () => apiClient.post('/auth/logout'),
  profile: () => apiClient.get('/auth/profile'),
};

export const seoAPI = {
  generateMeta: (data: any) => apiClient.post('/seo/meta', data),
  generateSitemap: () => apiClient.get('/seo/sitemap'),
  analyzeContent: (content: string) => apiClient.post('/seo/analyze', { content }),
  getKeywords: (topic: string) => apiClient.get('/seo/keywords', { topic }),
};

// Google API integrations
export const googleIntegrationAPI = {
  getFonts: () => googleApiClient.getFonts(),
  analyzeImage: (imageBase64: string) => googleApiClient.analyzeImage(imageBase64),
  translateText: (text: string, target: string) => googleApiClient.translateText(text, target),
  searchPlaces: (query: string) => googleApiClient.searchPlaces(query),
};