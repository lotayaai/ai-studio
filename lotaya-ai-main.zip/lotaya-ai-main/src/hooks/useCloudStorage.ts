// React hooks for Google Cloud Storage operations
import { useState, useCallback } from 'react';
import { cloudStorage, logoStorage, templateStorage, userUploadStorage } from '../utils/cloudStorage';
import { errorLogger } from '../utils/errorHandler';

export interface UseCloudStorageState {
  uploading: boolean;
  downloading: boolean;
  progress: number;
  error: string | null;
  url: string | null;
}

// Generic cloud storage hook
export function useCloudStorage() {
  const [state, setState] = useState<UseCloudStorageState>({
    uploading: false,
    downloading: false,
    progress: 0,
    error: null,
    url: null,
  });

  const uploadFile = useCallback(async (file: File, options: any) => {
    setState(prev => ({ ...prev, uploading: true, error: null, progress: 0 }));

    try {
      const url = await cloudStorage.uploadFile(file, options);
      setState(prev => ({ ...prev, url, progress: 100 }));
      return url;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Upload failed';
      setState(prev => ({ ...prev, error: errorMessage }));
      throw error;
    } finally {
      setState(prev => ({ ...prev, uploading: false }));
    }
  }, []);

  const downloadFile = useCallback(async (options: any) => {
    setState(prev => ({ ...prev, downloading: true, error: null }));

    try {
      const buffer = await cloudStorage.downloadFile(options);
      return buffer;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Download failed';
      setState(prev => ({ ...prev, error: errorMessage }));
      throw error;
    } finally {
      setState(prev => ({ ...prev, downloading: false }));
    }
  }, []);

  const getSignedUrl = useCallback(async (options: any, expirationMinutes?: number) => {
    try {
      const signedUrl = await cloudStorage.getSignedUrl(options, expirationMinutes);
      setState(prev => ({ ...prev, url: signedUrl }));
      return signedUrl;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to get signed URL';
      setState(prev => ({ ...prev, error: errorMessage }));
      throw error;
    }
  }, []);

  return {
    ...state,
    uploadFile,
    downloadFile,
    getSignedUrl,
  };
}

// Logo storage hook
export function useLogoStorage() {
  const [state, setState] = useState<UseCloudStorageState>({
    uploading: false,
    downloading: false,
    progress: 0,
    error: null,
    url: null,
  });

  const uploadLogo = useCallback(async (file: File, logoId: string) => {
    setState(prev => ({ ...prev, uploading: true, error: null, progress: 0 }));

    try {
      const url = await logoStorage.upload(file, logoId);
      setState(prev => ({ ...prev, url, progress: 100 }));
      return url;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Logo upload failed';
      setState(prev => ({ ...prev, error: errorMessage }));
      
      errorLogger.logError({
        message: `Logo upload error: ${errorMessage}`,
        stack: error instanceof Error ? error.stack : undefined,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      
      throw error;
    } finally {
      setState(prev => ({ ...prev, uploading: false }));
    }
  }, []);

  const downloadLogo = useCallback(async (logoId: string, fileName: string) => {
    setState(prev => ({ ...prev, downloading: true, error: null }));

    try {
      const buffer = await logoStorage.download(logoId, fileName);
      return buffer;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Logo download failed';
      setState(prev => ({ ...prev, error: errorMessage }));
      throw error;
    } finally {
      setState(prev => ({ ...prev, downloading: false }));
    }
  }, []);

  return {
    ...state,
    uploadLogo,
    downloadLogo,
  };
}

// Template storage hook
export function useTemplateStorage() {
  const [state, setState] = useState<UseCloudStorageState>({
    uploading: false,
    downloading: false,
    progress: 0,
    error: null,
    url: null,
  });

  const [templates, setTemplates] = useState<string[]>([]);

  const uploadTemplate = useCallback(async (file: File, templateId: string) => {
    setState(prev => ({ ...prev, uploading: true, error: null, progress: 0 }));

    try {
      const url = await templateStorage.upload(file, templateId);
      setState(prev => ({ ...prev, url, progress: 100 }));
      return url;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Template upload failed';
      setState(prev => ({ ...prev, error: errorMessage }));
      throw error;
    } finally {
      setState(prev => ({ ...prev, uploading: false }));
    }
  }, []);

  const listTemplates = useCallback(async (templateId?: string) => {
    try {
      const templateList = await templateStorage.list(templateId);
      setTemplates(templateList);
      return templateList;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to list templates';
      setState(prev => ({ ...prev, error: errorMessage }));
      throw error;
    }
  }, []);

  return {
    ...state,
    templates,
    uploadTemplate,
    listTemplates,
  };
}

// User upload storage hook
export function useUserUploadStorage() {
  const [state, setState] = useState<UseCloudStorageState>({
    uploading: false,
    downloading: false,
    progress: 0,
    error: null,
    url: null,
  });

  const uploadUserFile = useCallback(async (file: File, userId: string) => {
    setState(prev => ({ ...prev, uploading: true, error: null, progress: 0 }));

    try {
      const url = await userUploadStorage.upload(file, userId);
      setState(prev => ({ ...prev, url, progress: 100 }));
      return url;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'User file upload failed';
      setState(prev => ({ ...prev, error: errorMessage }));
      throw error;
    } finally {
      setState(prev => ({ ...prev, uploading: false }));
    }
  }, []);

  const getUserFileUrl = useCallback(async (userId: string, fileName: string) => {
    try {
      const signedUrl = await userUploadStorage.getSignedUrl(userId, fileName);
      setState(prev => ({ ...prev, url: signedUrl }));
      return signedUrl;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to get user file URL';
      setState(prev => ({ ...prev, error: errorMessage }));
      throw error;
    }
  }, []);

  return {
    ...state,
    uploadUserFile,
    getUserFileUrl,
  };
}