// Custom React hooks for Google API integrations
import { useState, useCallback } from 'react';
import { googleFontsAPI, googleVisionAPI, googleTranslateAPI, googlePlacesAPI } from '../utils/googleApiClient';
import { errorLogger } from '../utils/errorHandler';

export interface UseGoogleApiState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

// Google Fonts Hook
export function useGoogleFonts() {
  const [fonts, setFonts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchFonts = useCallback(async (sort: string = 'popularity') => {
    setLoading(true);
    setError(null);

    try {
      const response = await googleFontsAPI.getFonts(sort);
      setFonts(response.data.items || []);
      return response.data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch fonts';
      setError(errorMessage);
      
      errorLogger.logError({
        message: `Google Fonts API error: ${errorMessage}`,
        stack: err instanceof Error ? err.stack : undefined,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    fonts,
    loading,
    error,
    fetchFonts
  };
}

// Google Vision API Hook
export function useGoogleVision() {
  const [analysis, setAnalysis] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const analyzeImage = useCallback(async (imageFile: File) => {
    setLoading(true);
    setError(null);

    try {
      // Convert file to base64
      const base64 = await fileToBase64(imageFile);
      const response = await googleVisionAPI.analyzeImage(base64);
      
      setAnalysis(response.data);
      return response.data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to analyze image';
      setError(errorMessage);
      
      errorLogger.logError({
        message: `Google Vision API error: ${errorMessage}`,
        stack: err instanceof Error ? err.stack : undefined,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const detectText = useCallback(async (imageFile: File) => {
    setLoading(true);
    setError(null);

    try {
      const base64 = await fileToBase64(imageFile);
      const response = await googleVisionAPI.detectText(base64);
      
      const textAnnotations = response.data.responses?.[0]?.textAnnotations || [];
      const detectedText = textAnnotations.length > 0 ? textAnnotations[0].description : '';
      
      return detectedText;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to detect text';
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    analysis,
    loading,
    error,
    analyzeImage,
    detectText
  };
}

// Google Translate Hook
export function useGoogleTranslate() {
  const [translation, setTranslation] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const translateText = useCallback(async (text: string, targetLanguage: string) => {
    setLoading(true);
    setError(null);

    try {
      const response = await googleTranslateAPI.translate(text, targetLanguage);
      const translatedText = response.data.data?.translations?.[0]?.translatedText || text;
      
      setTranslation(translatedText);
      return translatedText;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to translate text';
      setError(errorMessage);
      
      errorLogger.logError({
        message: `Google Translate API error: ${errorMessage}`,
        stack: err instanceof Error ? err.stack : undefined,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const detectLanguage = useCallback(async (text: string) => {
    try {
      const response = await googleTranslateAPI.detectLanguage(text);
      return response.data.data?.detections?.[0]?.[0]?.language || 'en';
    } catch (err) {
      console.error('Language detection failed:', err);
      return 'en'; // Default to English
    }
  }, []);

  return {
    translation,
    loading,
    error,
    translateText,
    detectLanguage
  };
}

// Google Places Hook
export function useGooglePlaces() {
  const [places, setPlaces] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const searchPlaces = useCallback(async (query: string) => {
    setLoading(true);
    setError(null);

    try {
      const response = await googlePlacesAPI.searchPlaces(query);
      const results = response.data.results || [];
      
      setPlaces(results);
      return results;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to search places';
      setError(errorMessage);
      
      errorLogger.logError({
        message: `Google Places API error: ${errorMessage}`,
        stack: err instanceof Error ? err.stack : undefined,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });
      
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    places,
    loading,
    error,
    searchPlaces
  };
}

// Utility function to convert file to base64
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data:image/jpeg;base64, prefix
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = error => reject(error);
  });
}