// Custom React hooks for API interactions with comprehensive error handling
import { useState, useEffect, useCallback } from 'react';
import { apiClient, ApiResponse } from '../utils/apiClient';
import { errorLogger } from '../utils/errorHandler';

export interface UseApiState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export interface UseApiOptions {
  immediate?: boolean;
  onSuccess?: (data: any) => void;
  onError?: (error: string) => void;
}

// Generic API hook
export function useApi<T>(
  apiCall: () => Promise<ApiResponse<T>>,
  options: UseApiOptions = {}
): UseApiState<T> {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { immediate = true, onSuccess, onError } = options;

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await apiCall();
      setData(response.data);
      
      if (onSuccess) {
        onSuccess(response.data);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
      setError(errorMessage);
      
      errorLogger.logError({
        message: `API call failed: ${errorMessage}`,
        stack: err instanceof Error ? err.stack : undefined,
        timestamp: new Date(),
        userAgent: navigator.userAgent,
        url: window.location.href
      });

      if (onError) {
        onError(errorMessage);
      }
    } finally {
      setLoading(false);
    }
  }, [apiCall, onSuccess, onError]);

  useEffect(() => {
    if (immediate) {
      fetchData();
    }
  }, [fetchData, immediate]);

  return {
    data,
    loading,
    error,
    refetch: fetchData
  };
}

// Logo generation hook
export function useLogoGeneration() {
  const [generating, setGenerating] = useState(false);
  const [logos, setLogos] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  const generateLogos = useCallback(async (data: any) => {
    setGenerating(true);
    setError(null);

    try {
      const response = await apiClient.post('/logos/generate', data);
      setLogos(response.data.logos || []);
      return response.data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Logo generation failed';
      setError(errorMessage);
      throw err;
    } finally {
      setGenerating(false);
    }
  }, []);

  return {
    generateLogos,
    generating,
    logos,
    error
  };
}

// Social media content hook
export function useSocialMediaGeneration() {
  const [generating, setGenerating] = useState(false);
  const [content, setContent] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const generateContent = useCallback(async (type: 'post' | 'story', data: any) => {
    setGenerating(true);
    setError(null);

    try {
      const endpoint = type === 'post' ? '/social-media/posts' : '/social-media/stories';
      const response = await apiClient.post(endpoint, data);
      setContent(response.data);
      return response.data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Content generation failed';
      setError(errorMessage);
      throw err;
    } finally {
      setGenerating(false);
    }
  }, []);

  return {
    generateContent,
    generating,
    content,
    error
  };
}

// Template customization hook
export function useTemplateCustomization() {
  const [customizing, setCustomizing] = useState(false);
  const [customizedTemplate, setCustomizedTemplate] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const customizeTemplate = useCallback(async (templateId: string, customizations: any) => {
    setCustomizing(true);
    setError(null);

    try {
      const response = await apiClient.post(`/templates/${templateId}/customize`, customizations);
      setCustomizedTemplate(response.data);
      return response.data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Template customization failed';
      setError(errorMessage);
      throw err;
    } finally {
      setCustomizing(false);
    }
  }, []);

  return {
    customizeTemplate,
    customizing,
    customizedTemplate,
    error
  };
}

// Authentication hook
export function useAuth() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const login = useCallback(async (credentials: any) => {
    setLoading(true);
    setError(null);

    try {
      const response = await apiClient.post('/auth/login', credentials);
      const { user, token } = response.data;
      
      localStorage.setItem('authToken', token);
      apiClient.setAuthToken(token);
      setUser(user);
      
      return response.data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Login failed';
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await apiClient.post('/auth/logout');
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      localStorage.removeItem('authToken');
      apiClient.setAuthToken('');
      setUser(null);
    }
  }, []);

  const register = useCallback(async (userData: any) => {
    setLoading(true);
    setError(null);

    try {
      const response = await apiClient.post('/auth/register', userData);
      return response.data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Registration failed';
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // Check for existing auth token on mount
  useEffect(() => {
    const token = localStorage.getItem('authToken');
    if (token) {
      apiClient.setAuthToken(token);
      // Verify token and get user profile
      apiClient.get('/auth/profile')
        .then(response => {
          setUser(response.data);
        })
        .catch(() => {
          localStorage.removeItem('authToken');
          apiClient.setAuthToken('');
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      setLoading(false);
    }
  }, []);

  return {
    user,
    loading,
    error,
    login,
    logout,
    register,
    isAuthenticated: !!user
  };
}

// File upload hook
export function useFileUpload() {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const uploadFile = useCallback(async (file: File, endpoint: string) => {
    setUploading(true);
    setError(null);
    setProgress(0);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch(`${apiClient['config'].baseURL}${endpoint}`, {
        method: 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Upload failed: ${response.statusText}`);
      }

      const data = await response.json();
      setProgress(100);
      return data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Upload failed';
      setError(errorMessage);
      throw err;
    } finally {
      setUploading(false);
    }
  }, []);

  return {
    uploadFile,
    uploading,
    progress,
    error
  };
}