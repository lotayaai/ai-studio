import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { 
  CreditCard, 
  FileText, 
  Shirt, 
  Mail, 
  Gift, 
  Calendar,
  QrCode,
  Presentation,
  Download,
  Eye,
  Edit
} from 'lucide-react';
import { useTemplateCustomization, useApi } from '../hooks/useApi';
import { businessTemplatesAPI } from '../utils/apiClient';
import LoadingSpinner from './LoadingSpinner';
import SEOHead from './SEOHead';

const BusinessTemplates: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const { customizeTemplate, customizing, customizedTemplate, error } = useTemplateCustomization();
  
  // Fetch templates from API
  const { data: apiTemplates, loading: templatesLoading } = useApi(
    () => businessTemplatesAPI.list(selectedCategory === 'all' ? undefined : selectedCategory),
    { immediate: true }
  );

  const categories = [
    { id: 'all', name: 'All Templates' },
    { id: 'business', name: 'Business' },
    { id: 'marketing', name: 'Marketing' },
    { id: 'events', name: 'Events' },
    { id: 'apparel', name: 'Apparel' },
  ];

  const templates = [
    { 
      id: 1, 
      name: 'Business Card', 
      category: 'business', 
      icon: CreditCard, 
      size: '3.5x2 in',
      description: 'Professional business cards with modern design'
    },
    { 
      id: 2, 
      name: 'Letterhead', 
      category: 'business', 
      icon: FileText, 
      size: '8.5x11 in',
      description: 'Corporate letterheads for official correspondence'
    },
    { 
      id: 3, 
      name: 'T-Shirt Design', 
      category: 'apparel', 
      icon: Shirt, 
      size: 'Custom',
      description: 'Custom t-shirt designs for brands and events'
    },
    { 
      id: 4, 
      name: 'Email Signature', 
      category: 'business', 
      icon: Mail, 
      size: 'Responsive',
      description: 'Professional email signatures with contact info'
    },
    { 
      id: 5, 
      name: 'Flyer', 
      category: 'marketing', 
      icon: FileText, 
      size: '8.5x11 in',
      description: 'Eye-catching flyers for promotions and events'
    },
    { 
      id: 6, 
      name: 'Poster', 
      category: 'marketing', 
      icon: FileText, 
      size: '18x24 in',
      description: 'Large format posters for advertising'
    },
    { 
      id: 7, 
      name: 'Gift Certificate', 
      category: 'business', 
      icon: Gift, 
      size: '8.5x3.5 in',
      description: 'Professional gift certificates and vouchers'
    },
    { 
      id: 8, 
      name: 'Invitation', 
      category: 'events', 
      icon: Calendar, 
      size: '5x7 in',
      description: 'Elegant invitations for special events'
    },
    { 
      id: 9, 
      name: 'QR Code', 
      category: 'marketing', 
      icon: QrCode, 
      size: 'Scalable',
      description: 'Custom QR codes with branding'
    },
    { 
      id: 10, 
      name: 'Presentation', 
      category: 'business', 
      icon: Presentation, 
      size: '16:9',
      description: 'Professional presentation templates'
    },
    { 
      id: 11, 
      name: 'Menu', 
      category: 'business', 
      icon: FileText, 
      size: '8.5x14 in',
      description: 'Restaurant and cafe menu designs'
    },
    { 
      id: 12, 
      name: 'Thank You Card', 
      category: 'events', 
      icon: Calendar, 
      size: '5x3.5 in',
      description: 'Personalized thank you cards'
    },
  ];

  // Use API templates if available, otherwise fallback to mock data
  const availableTemplates = apiTemplates?.templates || templates;
  const filteredTemplates = selectedCategory === 'all' 
    ? availableTemplates 
    : availableTemplates.filter((template: any) => template.category === selectedCategory);

  useGSAP(() => {
    gsap.fromTo('.template-card',
      { y: 50, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, stagger: 0.1, ease: "power3.out" }
    );
  }, [selectedCategory]);

  const handleCustomizeTemplate = async (templateId: string) => {
    try {
      await customizeTemplate(templateId, {
        style: 'modern',
        colorScheme: 'professional',
        customizations: {}
      });
    } catch (err) {
      console.error('Template customization failed:', err);
    }
  };

  return (
    <section id="templates" className="py-20 bg-[#0B0F19] relative">
      <SEOHead
        title="Business Templates - Professional Marketing Materials | Lotaya AI"
        description="Create business cards, letterheads, flyers, and marketing materials with AI-powered design templates."
        keywords={['business templates', 'business cards', 'marketing materials', 'professional design', 'templates']}
        canonicalUrl="https://lotaya.io/business-templates"
      />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#C0C0C0] mb-6">
            Business & Marketing Templates
          </h2>
          <p className="text-xl text-[#D3D3D3] max-w-3xl mx-auto">
            Turn your business concepts into professional templates. From business cards to presentations—transform ideas into stunning designs in minutes.
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          className="flex flex-wrap justify-center gap-4 mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          {categories.map((category) => (
            <motion.button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                selectedCategory === category.id
                  ? 'bg-[#C0C0C0] text-[#0B0F19]'
                  : 'bg-gray-800/50 text-[#D3D3D3] hover:bg-gray-700/50'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {category.name}
            </motion.button>
          ))}
        </motion.div>

        {/* Templates Grid */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          {templatesLoading && (
            <div className="col-span-full flex justify-center py-12">
              <LoadingSpinner size="lg" message="Loading templates..." />
            </div>
          )}
          
          {filteredTemplates.map((template, index) => {
            const Icon = template.icon;
            
            return (
              <motion.div
                key={template.id}
                className="template-card bg-gray-900/50 backdrop-blur-lg rounded-2xl p-6 border border-gray-800 hover:border-[#C0C0C0]/50 transition-all duration-300 group"
                whileHover={{ scale: 1.03, y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                {/* Template Preview */}
                <div className="aspect-[4/3] bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl mb-4 flex items-center justify-center relative overflow-hidden">
                  <Icon className="w-12 h-12 text-[#C0C0C0] opacity-50 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  {/* Overlay with quick actions */}
                  <div className="absolute inset-0 bg-[#C0C0C0]/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <div className="flex gap-2">
                      <motion.button
                        className="bg-[#C0C0C0] text-[#0B0F19] p-2 rounded-lg hover:bg-[#D3D3D3] transition-colors"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <Eye className="w-4 h-4" />
                      </motion.button>
                      <motion.button
                        className="bg-[#C0C0C0] text-[#0B0F19] p-2 rounded-lg hover:bg-[#D3D3D3] transition-colors"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <Edit className="w-4 h-4" />
                      </motion.button>
                    </div>
                  </div>

                  {/* Category Badge */}
                  <div className="absolute top-2 left-2 bg-[#C0C0C0]/20 backdrop-blur-sm text-[#C0C0C0] text-xs px-2 py-1 rounded-full">
                    {template.category}
                  </div>
                </div>

                {/* Template Info */}
                <h3 className="text-lg font-semibold text-[#C0C0C0] mb-2">
                  {template.name}
                </h3>
                <p className="text-[#D3D3D3] text-sm mb-3">
                  {template.description}
                </p>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[#C0C0C0] text-sm font-medium">
                    {template.size}
                  </span>
                  <span className="text-[#D3D3D3] text-xs bg-gray-800 px-2 py-1 rounded">
                    Template
                  </span>
                </div>

                {/* Action Button */}
                <motion.button
                  onClick={() => handleCustomizeTemplate(template.id)}
                  disabled={customizing}
                  className="w-full bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] text-[#0B0F19] py-3 rounded-xl font-medium flex items-center justify-center gap-2 hover:shadow-lg transition-all duration-300"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {customizing ? (
                    <LoadingSpinner size="sm" message="" />
                  ) : (
                    <>
                      <Edit className="w-4 h-4" />
                      Customize Template
                    </>
                  )}
                </motion.button>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Error Display */}
        {error && (
          <div className="mt-8 p-4 bg-red-500/20 border border-red-500/50 rounded-lg max-w-2xl mx-auto">
            <p className="text-red-400 text-center">{error}</p>
          </div>
        )}

        {/* Call to Action */}
        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <p className="text-[#D3D3D3] mb-6">
            Can't find what you're looking for? Our AI can create custom templates for any business need.
          </p>
          <motion.button
            className="bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] text-[#0B0F19] px-8 py-4 rounded-xl font-semibold text-lg hover:shadow-lg transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Request Custom Template
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default BusinessTemplates;