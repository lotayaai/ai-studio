import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { Search, Heart, Download, Edit, Eye, Sparkles } from 'lucide-react';
import { useLogoGeneration } from '../hooks/useApi';
import { useGoogleFonts } from '../hooks/useGoogleApi';
import LoadingSpinner from './LoadingSpinner';
import GoogleFontSelector from './GoogleFontSelector';
import SEOHead from './SEOHead';

const LogoGenerator: React.FC = () => {
  const [businessName, setBusinessName] = useState('');
  const [keywords, setKeywords] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [shortlist, setShortlist] = useState<number[]>([]);
  const [selectedFont, setSelectedFont] = useState<any>(null);
  const [showFontSelector, setShowFontSelector] = useState(false);
  
  const { generateLogos, generating, logos, error } = useLogoGeneration();
  const { fonts } = useGoogleFonts();

  const categories = [
    'Construction', 'Cool', 'DJ', 'Restaurant', 'Letter', 'Real Estate',
    'Circle', 'Fashion', 'Cartoon', 'Travel', 'Cafe', 'Eagle',
    'Podcast', 'Bakery', 'Text', 'Icon', 'Word', 'Team',
    'App', 'Barber', 'Font', 'Web', 'Pizza', 'Shop',
    'Simple', 'Symbol', 'Beauty', 'Coffee', 'Doctor', 'Gym',
    'Lion', 'Music'
  ];

  const mockLogos = [
    { id: 1, name: 'TechNova Logo', style: 'Modern Tech', colors: ['#C0C0C0', '#D3D3D3'] },
    { id: 2, name: 'Creative Studio', style: 'Minimalist', colors: ['#C0C0C0', '#0B0F19'] },
    { id: 3, name: 'Business Pro', style: 'Professional', colors: ['#D3D3D3', '#C0C0C0'] },
    { id: 4, name: 'Design Hub', style: 'Creative', colors: ['#C0C0C0', '#D3D3D3'] },
  ];

  useGSAP(() => {
    gsap.fromTo('.logo-card',
      { y: 50, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, stagger: 0.1, ease: "power3.out" }
    );
  }, [businessName]);

  const toggleShortlist = (logoId: number) => {
    setShortlist(prev => 
      prev.includes(logoId) 
        ? prev.filter(id => id !== logoId)
        : [...prev, logoId]
    );
  };

  const handleGenerateLogos = async () => {
    if (!businessName.trim()) {
      alert('Please enter a business name');
      return;
    }

    try {
      await generateLogos({
        businessName: businessName.trim(),
        keywords: keywords.trim(),
        category: selectedCategory,
        font: selectedFont?.family,
        style: 'modern',
        colorScheme: 'professional'
      });
    } catch (err) {
      console.error('Logo generation failed:', err);
    }
  };

  return (
    <section id="logo-generator" className="py-20 bg-[#0B0F19] relative overflow-hidden">
      <SEOHead
        title="AI Logo Generator - Create Professional Logos Instantly | Lotaya AI"
        description="Generate unique, professional logos for your business using advanced AI technology. Turn your ideas into stunning brand designs in seconds."
        keywords={['AI logo generator', 'logo design', 'business logos', 'brand identity', 'professional logos']}
        canonicalUrl="https://lotaya.io/logo-generator"
      />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#C0C0C0] mb-6">
            AI Logo Generator
          </h2>
          <p className="text-xl text-[#D3D3D3] max-w-3xl mx-auto">
            Turn your business ideas into unique, professional logos in seconds using our advanced AI technology.
          </p>
        </motion.div>

        {/* Input Section */}
        <motion.div
          className="max-w-4xl mx-auto mb-16 bg-gray-900/50 backdrop-blur-lg rounded-2xl p-8 border border-gray-800"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Business Name Input */}
            <div>
              <label className="block text-[#D3D3D3] font-medium mb-2">
                Business Name
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  placeholder="Enter your business name"
                  className="w-full bg-gray-800/50 border border-gray-700 rounded-xl px-4 py-3 text-[#D3D3D3] placeholder-gray-500 focus:border-[#C0C0C0] focus:outline-none transition-colors"
                />
                <Sparkles className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#C0C0C0] opacity-50" />
              </div>
            </div>

            {/* Keywords Input */}
            <div>
              <label className="block text-[#D3D3D3] font-medium mb-2">
                Keywords (Optional)
              </label>
              <input
                type="text"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="modern, sleek, professional"
                className="w-full bg-gray-800/50 border border-gray-700 rounded-xl px-4 py-3 text-[#D3D3D3] placeholder-gray-500 focus:border-[#C0C0C0] focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* Category Selection */}
          <div className="mb-6">
            <label className="block text-[#D3D3D3] font-medium mb-3">
              Industry Category
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-2">
              {categories.map((category) => (
                <motion.button
                  key={category}
                  onClick={() => setSelectedCategory(category === selectedCategory ? '' : category)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                    selectedCategory === category
                      ? 'bg-[#C0C0C0] text-[#0B0F19]'
                      : 'bg-gray-800/50 text-[#D3D3D3] hover:bg-gray-700/50'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {category}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Font Selection */}
          <div className="mb-6">
            <label className="block text-[#D3D3D3] font-medium mb-3">
              Font Style (Optional)
            </label>
            <div className="flex items-center gap-4">
              <div className="flex-1">
                {selectedFont ? (
                  <div className="bg-gray-800/50 border border-gray-700 rounded-xl px-4 py-3 flex items-center justify-between">
                    <span className="text-[#D3D3D3]" style={{ fontFamily: selectedFont.family }}>
                      {selectedFont.family}
                    </span>
                    <button
                      onClick={() => setSelectedFont(null)}
                      className="text-[#C0C0C0] hover:text-red-400 transition-colors"
                    >
                      ×
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowFontSelector(!showFontSelector)}
                    className="w-full bg-gray-800/50 border border-gray-700 rounded-xl px-4 py-3 text-left text-[#D3D3D3] hover:border-[#C0C0C0] transition-colors"
                  >
                    Choose a Google Font...
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Google Font Selector */}
          {showFontSelector && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-6"
            >
              <GoogleFontSelector
                onFontSelect={(font) => {
                  setSelectedFont(font);
                  setShowFontSelector(false);
                }}
                selectedFont={selectedFont?.family}
              />
            </motion.div>
          )}

          {/* Generate Button */}
          <motion.button
            onClick={handleGenerateLogos}
            disabled={generating || !businessName.trim()}
            className="w-full bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] text-[#0B0F19] py-4 rounded-xl font-semibold text-lg flex items-center justify-center gap-2 hover:shadow-lg transition-all duration-300"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {generating ? (
              <LoadingSpinner size="sm" message="" />
            ) : (
              <>
                <Search className="w-5 h-5" />
                Generate Logos
              </>
            )}
          </motion.button>
          
          {error && (
            <div className="mt-4 p-4 bg-red-500/20 border border-red-500/50 rounded-lg">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}
        </motion.div>

        {/* Logo Results */}
        {(businessName && logos.length > 0) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-2xl font-bold text-[#C0C0C0] mb-8 text-center">
              Logo Suggestions for "{businessName}"
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {(logos.length > 0 ? logos : mockLogos).map((logo, index) => (
                <motion.div
                  key={logo.id}
                  className="logo-card bg-gray-900/50 backdrop-blur-lg rounded-2xl p-6 border border-gray-800 hover:border-[#C0C0C0]/50 transition-all duration-300 group"
                  whileHover={{ scale: 1.03, y: -5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  {/* Logo Preview */}
                  <div className="aspect-square bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl mb-4 flex items-center justify-center relative overflow-hidden">
                    <div 
                      className="w-20 h-20 rounded-lg"
                      style={{
                        background: `linear-gradient(135deg, ${logo.colors[0]}, ${logo.colors[1]})`,
                        fontFamily: selectedFont?.family || 'Inter'
                      }}
                    />
                    <div 
                      className="absolute inset-0 flex items-center justify-center text-white font-bold text-sm"
                      style={{
                        fontFamily: selectedFont?.family || 'Inter'
                      }}
                    >
                      {businessName.charAt(0).toUpperCase()}
                    </div>
                    
                    {/* Shortlist Button */}
                    <motion.button
                      onClick={() => toggleShortlist(logo.id)}
                      className={`absolute top-2 right-2 p-2 rounded-full transition-all duration-300 ${
                        shortlist.includes(logo.id)
                          ? 'bg-red-500 text-white'
                          : 'bg-gray-800/80 text-[#D3D3D3] hover:bg-red-500 hover:text-white'
                      }`}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Heart className={`w-4 h-4 ${shortlist.includes(logo.id) ? 'fill-current' : ''}`} />
                    </motion.button>
                  </div>

                  {/* Logo Info */}
                  <h4 className="text-lg font-semibold text-[#C0C0C0] mb-2">
                    {logo.name}
                  </h4>
                  <p className="text-[#D3D3D3] text-sm mb-4">
                    {logo.style}
                  </p>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <motion.button
                      className="flex-1 bg-[#C0C0C0] text-[#0B0F19] py-2 px-3 rounded-lg text-sm font-medium flex items-center justify-center gap-1 hover:bg-[#D3D3D3] transition-colors"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Edit className="w-4 h-4" />
                      Edit
                    </motion.button>
                    <motion.button
                      className="bg-gray-800 text-[#D3D3D3] py-2 px-3 rounded-lg hover:bg-gray-700 transition-colors"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Eye className="w-4 h-4" />
                    </motion.button>
                    <motion.button
                      className="bg-gray-800 text-[#D3D3D3] py-2 px-3 rounded-lg hover:bg-gray-700 transition-colors"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Download className="w-4 h-4" />
                    </motion.button>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default LogoGenerator;