import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Menu, X, Sparkles } from 'lucide-react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { useAuth } from '../hooks/useApi';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout, isAuthenticated } = useAuth();

  useGSAP(() => {
    gsap.fromTo('.header-nav', 
      { y: -100, opacity: 0 },
      { y: 0, opacity: 1, duration: 1, ease: "power3.out" }
    );

    gsap.fromTo('.nav-item',
      { y: -30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, stagger: 0.1, delay: 0.3 }
    );
  }, []);

  const navItems = ['Logo Generator', 'Social Media', 'Templates', 'Pricing', 'Contact'];

  const handleAuthAction = () => {
    if (isAuthenticated) {
      logout();
    } else {
      // Redirect to login page or open login modal
      window.location.href = '/login';
    }
  };

  return (
    <header className="header-nav fixed top-0 left-0 right-0 z-40 bg-[#0B0F19]/95 backdrop-blur-lg border-b border-gray-800/50">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <motion.div 
            className="flex items-center space-x-2"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400 }}
          >
            <div className="relative">
              <Sparkles className="w-8 h-8 text-[#C0C0C0]" />
              <motion.div
                className="absolute inset-0"
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles className="w-8 h-8 text-[#D3D3D3] opacity-30" />
              </motion.div>
            </div>
            <span className="text-xl font-bold text-[#C0C0C0]">Lotaya AI</span>
            <span className="hidden sm:block text-xs text-[#D3D3D3] ml-2 font-medium">Turn every thought into design</span>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item, index) => (
              <motion.a
                key={item}
                href={`#${item.toLowerCase().replace(' ', '-')}`}
                className="nav-item text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors duration-300 relative group"
                whileHover={{ y: -2 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                {item}
                <motion.div
                  className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#C0C0C0] group-hover:w-full transition-all duration-300"
                  layoutId="underline"
                />
              </motion.a>
            ))}
            <motion.button
              onClick={handleAuthAction}
              className="bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] text-[#0B0F19] px-6 py-2 rounded-lg font-medium hover:shadow-lg transition-all duration-300"
              whileHover={{ scale: 1.05, boxShadow: "0 10px 25px rgba(192, 192, 192, 0.3)" }}
              whileTap={{ scale: 0.95 }}
            >
              {isAuthenticated ? `Hi, ${user?.name || 'User'}` : 'Get Started'}
            </motion.button>
            
            {isAuthenticated && (
              <motion.button
                onClick={logout}
                className="text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors text-sm"
                whileHover={{ scale: 1.05 }}
              >
                Logout
              </motion.button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <motion.button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors"
              whileTap={{ scale: 0.9 }}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </motion.button>
          </div>
        </div>

        {/* Mobile Menu */}
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ 
            opacity: isMenuOpen ? 1 : 0, 
            height: isMenuOpen ? 'auto' : 0 
          }}
          transition={{ duration: 0.3 }}
          className="md:hidden overflow-hidden bg-[#0B0F19]/95"
        >
          <div className="py-4 space-y-4">
            {navItems.map((item) => (
              <motion.a
                key={item}
                href={`#${item.toLowerCase().replace(' ', '-')}`}
                className="block text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors duration-300 px-4 py-2"
                onClick={() => setIsMenuOpen(false)}
                whileHover={{ x: 10 }}
              >
                {item}
              </motion.a>
            ))}
            <motion.button
              onClick={handleAuthAction}
              className="mx-4 bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] text-[#0B0F19] px-6 py-2 rounded-lg font-medium w-full"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {isAuthenticated ? `Hi, ${user?.name || 'User'}` : 'Get Started'}
            </motion.button>
          </div>
        </motion.div>
      </nav>
    </header>
  );
};

export default Header;