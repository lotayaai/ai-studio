// Enhanced loading spinner with performance optimizations
import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles } from 'lucide-react';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  message?: string;
  showProgress?: boolean;
  progress?: number;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({
  size = 'md',
  message = 'Loading...',
  showProgress = false,
  progress = 0
}) => {
  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-12 h-12',
    lg: 'w-16 h-16'
  };

  const containerSizeClasses = {
    sm: 'p-4',
    md: 'p-8',
    lg: 'p-12'
  };

  return (
    <div className={`flex flex-col items-center justify-center ${containerSizeClasses[size]}`}>
      {/* Animated Spinner */}
      <motion.div
        className={`${sizeClasses[size]} relative mb-4`}
        animate={{ rotate: 360 }}
        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
      >
        <div className="absolute inset-0 border-4 border-gray-800 rounded-full" />
        <div className="absolute inset-0 border-4 border-transparent border-t-[#C0C0C0] rounded-full" />
        
        {/* Center icon */}
        <div className="absolute inset-0 flex items-center justify-center">
          <Sparkles className="w-1/2 h-1/2 text-[#C0C0C0]" />
        </div>
      </motion.div>

      {/* Progress Bar */}
      {showProgress && (
        <div className="w-32 mb-4">
          <div className="bg-gray-800 rounded-full h-2 overflow-hidden">
            <motion.div
              className="bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] h-full rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
          <div className="text-center mt-2 text-sm text-[#D3D3D3]">
            {Math.round(progress)}%
          </div>
        </div>
      )}

      {/* Loading Message */}
      <motion.p
        className="text-[#D3D3D3] text-center"
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        {message}
      </motion.p>
    </div>
  );
};

export default LoadingSpinner;