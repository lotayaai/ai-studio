// File uploader component with Google Cloud Storage integration
import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Upload, File, X, Check, AlertCircle } from 'lucide-react';
import { useCloudStorage } from '../hooks/useCloudStorage';
import LoadingSpinner from './LoadingSpinner';

interface FileUploaderProps {
  onUploadComplete?: (url: string) => void;
  onUploadError?: (error: string) => void;
  acceptedTypes?: string[];
  maxFileSize?: number; // in MB
  bucket: string;
  folder?: string;
  className?: string;
}

const FileUploader: React.FC<FileUploaderProps> = ({
  onUploadComplete,
  onUploadError,
  acceptedTypes = ['image/*'],
  maxFileSize = 10,
  bucket,
  folder = '',
  className = ''
}) => {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { uploading, progress, error, url, uploadFile } = useCloudStorage();

  const handleFileSelect = (files: FileList | null) => {
    if (!files) return;

    const validFiles: File[] = [];
    const errors: string[] = [];

    Array.from(files).forEach(file => {
      // Check file type
      const isValidType = acceptedTypes.some(type => {
        if (type.endsWith('/*')) {
          return file.type.startsWith(type.replace('/*', '/'));
        }
        return file.type === type;
      });

      if (!isValidType) {
        errors.push(`${file.name}: Invalid file type`);
        return;
      }

      // Check file size
      if (file.size > maxFileSize * 1024 * 1024) {
        errors.push(`${file.name}: File too large (max ${maxFileSize}MB)`);
        return;
      }

      validFiles.push(file);
    });

    if (errors.length > 0) {
      const errorMessage = errors.join(', ');
      if (onUploadError) onUploadError(errorMessage);
      return;
    }

    setSelectedFiles(validFiles);
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) return;

    try {
      const uploadPromises = selectedFiles.map(async (file) => {
        const fileName = folder ? `${folder}/${file.name}` : file.name;
        return uploadFile(file, {
          bucket,
          fileName,
          contentType: file.type,
          makePublic: true,
          metadata: {
            originalName: file.name,
            uploadedAt: new Date().toISOString(),
          }
        });
      });

      const urls = await Promise.all(uploadPromises);
      
      if (onUploadComplete) {
        onUploadComplete(urls[0]); // Return first URL for single file uploads
      }

      setSelectedFiles([]);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Upload failed';
      if (onUploadError) onUploadError(errorMessage);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files);
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* File Input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={acceptedTypes.join(',')}
        onChange={(e) => handleFileSelect(e.target.files)}
        className="hidden"
      />

      {/* Drop Zone */}
      <motion.div
        className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-300 ${
          dragActive
            ? 'border-[#C0C0C0] bg-[#C0C0C0]/10'
            : 'border-gray-700 hover:border-[#C0C0C0]/50'
        }`}
        onClick={() => fileInputRef.current?.click()}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        <Upload className="w-12 h-12 text-[#C0C0C0] mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-[#C0C0C0] mb-2">
          Upload Files
        </h3>
        <p className="text-[#D3D3D3] mb-2">
          Drag and drop files here, or click to select
        </p>
        <p className="text-[#D3D3D3] text-sm">
          Accepted: {acceptedTypes.join(', ')} • Max size: {maxFileSize}MB
        </p>
      </motion.div>

      {/* Selected Files */}
      {selectedFiles.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-[#C0C0C0] font-medium">Selected Files:</h4>
          {selectedFiles.map((file, index) => (
            <motion.div
              key={index}
              className="flex items-center justify-between bg-gray-800/50 rounded-lg p-3"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="flex items-center gap-3">
                <File className="w-5 h-5 text-[#C0C0C0]" />
                <div>
                  <p className="text-[#D3D3D3] font-medium">{file.name}</p>
                  <p className="text-[#D3D3D3] text-sm">
                    {(file.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              </div>
              
              <button
                onClick={() => removeFile(index)}
                className="text-red-400 hover:text-red-300 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </motion.div>
          ))}
        </div>
      )}

      {/* Upload Button */}
      {selectedFiles.length > 0 && (
        <motion.button
          onClick={handleUpload}
          disabled={uploading}
          className="w-full bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] text-[#0B0F19] py-3 rounded-xl font-semibold flex items-center justify-center gap-2 hover:shadow-lg transition-all duration-300"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          {uploading ? (
            <>
              <LoadingSpinner size="sm" message="" />
              Uploading... {Math.round(progress)}%
            </>
          ) : (
            <>
              <Upload className="w-5 h-5" />
              Upload {selectedFiles.length} file{selectedFiles.length > 1 ? 's' : ''}
            </>
          )}
        </motion.button>
      )}

      {/* Success Message */}
      {url && !uploading && (
        <motion.div
          className="flex items-center gap-2 p-3 bg-green-500/20 border border-green-500/50 rounded-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Check className="w-5 h-5 text-green-400" />
          <p className="text-green-400">Upload successful!</p>
        </motion.div>
      )}

      {/* Error Message */}
      {error && (
        <motion.div
          className="flex items-center gap-2 p-3 bg-red-500/20 border border-red-500/50 rounded-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <AlertCircle className="w-5 h-5 text-red-400" />
          <p className="text-red-400">{error}</p>
        </motion.div>
      )}
    </div>
  );
};

export default FileUploader;