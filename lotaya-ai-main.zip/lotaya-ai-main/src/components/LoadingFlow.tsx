import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';

interface LoadingFlowProps {
  onComplete: () => void;
}

const LoadingFlow: React.FC<LoadingFlowProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState(0);

  const stages = [
    "Turning thoughts into designs...",
    "Initializing AI Engine...",
    "Loading Creative Tools...",
    "Ready to transform ideas!"
  ];

  useGSAP(() => {
    const tl = gsap.timeline();
    
    // 3D cube animation
    tl.to(".loading-cube", {
      rotationY: 360,
      rotationX: 180,
      duration: 2,
      ease: "power2.inOut",
      repeat: -1
    });

    // Progress bar animation
    const progressTl = gsap.timeline();
    progressTl.to({}, {
      duration: 4,
      onUpdate: () => {
        const currentProgress = Math.floor(progressTl.progress() * 100);
        setProgress(currentProgress);
        
        if (currentProgress >= 25 && stage < 1) setStage(1);
        if (currentProgress >= 50 && stage < 2) setStage(2);
        if (currentProgress >= 75 && stage < 3) setStage(3);
      },
      onComplete: () => {
        setTimeout(() => onComplete(), 1000);
      }
    });
  }, [onComplete, stage]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-[#0B0F19] flex items-center justify-center z-50"
    >
      <div className="text-center">
        {/* 3D Cube */}
        <div className="loading-cube-container mb-8">
          <div className="loading-cube w-16 h-16 mx-auto relative">
            <div className="absolute inset-0 bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] rounded-lg shadow-2xl"></div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-80 max-w-md mx-auto mb-6">
          <div className="bg-gray-800 rounded-full h-2 overflow-hidden">
            <motion.div
              className="bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] h-full rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.1 }}
            />
          </div>
          <div className="flex justify-between mt-2 text-sm text-[#D3D3D3]">
            <span>{progress}%</span>
            <span>Loading...</span>
          </div>
        </div>

        {/* Stage Text */}
        <AnimatePresence mode="wait">
          <motion.p
            key={stage}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="text-[#D3D3D3] text-lg font-medium"
          >
            {stages[stage]}
          </motion.p>
        </AnimatePresence>

        {/* Lotaya AI Logo */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mt-8"
        >
          <h1 className="text-3xl font-bold text-[#C0C0C0] mb-2">Lotaya AI</h1>
          <p className="text-[#D3D3D3] text-sm">Turn every thought into design</p>
        </motion.div>
      </div>

      {/* Background particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-[#C0C0C0] rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0, 1, 0],
              scale: [0, 1, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>
    </motion.div>
  );
};

export default LoadingFlow;