import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { 
  Instagram, 
  Facebook, 
  Twitter, 
  Linkedin, 
  Youtube, 
  Monitor,
  Smartphone,
  Image,
  Video,
  Users
} from 'lucide-react';
import { useSocialMediaGeneration } from '../hooks/useApi';
import LoadingSpinner from './LoadingSpinner';
import SEOHead from './SEOHead';

const SocialMediaTools: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('covers');
  const { generateContent, generating, content, error } = useSocialMediaGeneration();

  const categories = [
    { id: 'covers', name: 'Covers & Banners', icon: Monitor },
    { id: 'posts', name: 'Posts & Stories', icon: Image },
    { id: 'profiles', name: 'Profile Pictures', icon: Users },
    { id: 'videos', name: 'Video Content', icon: Video },
  ];

  const designTypes = {
    covers: [
      { name: 'Facebook Cover', size: '1200x630', platform: 'facebook' },
      { name: 'YouTube Banner', size: '2560x1440', platform: 'youtube' },
      { name: 'LinkedIn Banner', size: '1584x396', platform: 'linkedin' },
      { name: 'Twitter Header', size: '1500x500', platform: 'twitter' },
      { name: 'Twitch Banner', size: '1200x480', platform: 'twitch' },
      { name: 'Pinterest Board Cover', size: '600x600', platform: 'pinterest' },
    ],
    posts: [
      { name: 'Instagram Post', size: '1080x1080', platform: 'instagram' },
      { name: 'Instagram Story', size: '1080x1920', platform: 'instagram' },
      { name: 'Facebook Post', size: '1200x630', platform: 'facebook' },
      { name: 'Facebook Ad', size: '1200x628', platform: 'facebook' },
      { name: 'LinkedIn Post', size: '1200x627', platform: 'linkedin' },
      { name: 'Pinterest Pin', size: '735x1102', platform: 'pinterest' },
    ],
    profiles: [
      { name: 'Facebook Profile Picture', size: '180x180', platform: 'facebook' },
      { name: 'Instagram Profile Picture', size: '320x320', platform: 'instagram' },
      { name: 'LinkedIn Profile Picture', size: '400x400', platform: 'linkedin' },
      { name: 'Twitter Profile Picture', size: '400x400', platform: 'twitter' },
    ],
    videos: [
      { name: 'Instagram Reel', size: '1080x1920', platform: 'instagram' },
      { name: 'TikTok Video', size: '1080x1920', platform: 'tiktok' },
      { name: 'YouTube Short', size: '1080x1920', platform: 'youtube' },
      { name: 'YouTube Video Thumbnail', size: '1280x720', platform: 'youtube' },
    ]
  };

  const platformIcons = {
    facebook: Facebook,
    instagram: Instagram,
    twitter: Twitter,
    linkedin: Linkedin,
    youtube: Youtube,
    pinterest: Monitor,
    twitch: Monitor,
    tiktok: Smartphone,
  };

  useGSAP(() => {
    gsap.fromTo('.social-card',
      { y: 50, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, stagger: 0.1, ease: "power3.out" }
    );
  }, [activeCategory]);

  const handleCreateDesign = async (designType: any) => {
    try {
      await generateContent('post', {
        platform: designType.platform,
        dimensions: designType.size,
        type: designType.name,
        style: 'modern'
      });
    } catch (err) {
      console.error('Design creation failed:', err);
    }
  };

  return (
    <section id="social-media" className="py-20 bg-gray-900/30 relative">
      <SEOHead
        title="Social Media Design Tools - Create Content for All Platforms | Lotaya AI"
        description="Design professional social media content for Instagram, Facebook, Twitter, and more with perfect dimensions and stunning designs."
        keywords={['social media design', 'Instagram posts', 'Facebook covers', 'social content', 'design tools']}
        canonicalUrl="https://lotaya.io/social-media-tools"
      />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[#C0C0C0] mb-6">
            Social Media Design Tools
          </h2>
          <p className="text-xl text-[#D3D3D3] max-w-3xl mx-auto">
            Turn your ideas into professional social media content for all platforms with perfect dimensions and stunning designs.
          </p>
        </motion.div>

        {/* Category Tabs */}
        <motion.div
          className="flex flex-wrap justify-center gap-4 mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <motion.button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                  activeCategory === category.id
                    ? 'bg-[#C0C0C0] text-[#0B0F19]'
                    : 'bg-gray-800/50 text-[#D3D3D3] hover:bg-gray-700/50'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Icon className="w-5 h-5" />
                {category.name}
              </motion.button>
            );
          })}
        </motion.div>

        {/* Design Templates Grid */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          {designTypes[activeCategory as keyof typeof designTypes]?.map((design, index) => {
            const PlatformIcon = platformIcons[design.platform as keyof typeof platformIcons];
            
            return (
              <motion.div
                key={design.name}
                className="social-card bg-gray-900/50 backdrop-blur-lg rounded-2xl p-6 border border-gray-800 hover:border-[#C0C0C0]/50 transition-all duration-300 group cursor-pointer"
                whileHover={{ scale: 1.03, y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                {/* Preview Area */}
                <div className="aspect-video bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl mb-4 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-[#C0C0C0]/20 to-[#D3D3D3]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <PlatformIcon className="w-12 h-12 text-[#C0C0C0] opacity-50 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  {/* Quick Preview Button */}
                  <motion.div
                    className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    initial={{ scale: 0 }}
                    whileHover={{ scale: 1 }}
                  >
                    <button 
                      onClick={() => handleCreateDesign(design)}
                      disabled={generating}
                      className="bg-[#C0C0C0] text-[#0B0F19] px-4 py-2 rounded-lg font-medium flex items-center gap-2"
                    >
                      {generating ? (
                        <LoadingSpinner size="sm" message="" />
                      ) : (
                        'Create Design'
                      )}
                    </button>
                  </motion.div>
                </div>

                {/* Design Info */}
                <h3 className="text-lg font-semibold text-[#C0C0C0] mb-2">
                  {design.name}
                </h3>
                <div className="flex items-center justify-between">
                  <span className="text-[#D3D3D3] text-sm">
                    {design.size}
                  </span>
                  <div className="flex items-center gap-1">
                    <PlatformIcon className="w-4 h-4 text-[#C0C0C0]" />
                    <span className="text-[#C0C0C0] text-sm capitalize">
                      {design.platform}
                    </span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Error Display */}
        {error && (
          <div className="mt-8 p-4 bg-red-500/20 border border-red-500/50 rounded-lg max-w-2xl mx-auto">
            <p className="text-red-400 text-center">{error}</p>
          </div>
        )}

        {/* Call to Action */}
        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <motion.button
            className="bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] text-[#0B0F19] px-8 py-4 rounded-xl font-semibold text-lg hover:shadow-lg transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Start Creating Social Media Content
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default SocialMediaTools;