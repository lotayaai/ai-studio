import React from 'react';
import { motion } from 'framer-motion';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { Search, Home, ArrowLeft, Sparkles } from 'lucide-react';

const NotFound: React.FC = () => {
  useGSAP(() => {
    // Animate 404 text
    gsap.fromTo('.error-404',
      { scale: 0, rotation: -180 },
      { scale: 1, rotation: 0, duration: 1.2, ease: "back.out(1.7)" }
    );

    // Floating animation for sparkles
    gsap.to('.floating-sparkle', {
      y: -20,
      duration: 2,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut",
      stagger: 0.3
    });

    // Parallax background elements
    gsap.to('.parallax-element', {
      y: -50,
      duration: 3,
      repeat: -1,
      yoyo: true,
      ease: "power1.inOut",
      stagger: 0.5
    });
  }, []);

  const handleGoHome = () => {
    window.location.href = '/';
  };

  const handleGoBack = () => {
    window.history.back();
  };

  const suggestions = [
    'AI Logo Generator',
    'Social Media Tools',
    'Business Templates',
    'Design Studio'
  ];

  return (
    <div className="min-h-screen bg-[#0B0F19] flex items-center justify-center px-4 relative overflow-hidden">
      {/* Background Animation */}
      <div className="absolute inset-0 opacity-10">
        <div className="parallax-element absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] rounded-full blur-3xl" />
        <div className="parallax-element absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-to-l from-[#D3D3D3] to-[#C0C0C0] rounded-full blur-3xl" />
      </div>

      {/* Floating Sparkles */}
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className="floating-sparkle absolute"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
        >
          <Sparkles className="w-4 h-4 text-[#C0C0C0] opacity-30" />
        </div>
      ))}

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center max-w-4xl mx-auto relative z-10"
      >
        {/* 404 Number */}
        <motion.div
          className="error-404 mb-8"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
        >
          <h1 className="text-9xl sm:text-[12rem] lg:text-[16rem] font-bold text-[#C0C0C0] leading-none opacity-20">
            404
          </h1>
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="mb-12"
        >
          <h2 className="text-4xl lg:text-6xl font-bold text-[#C0C0C0] mb-6">
            Page Not Found
          </h2>
          <p className="text-xl text-[#D3D3D3] mb-8 max-w-2xl mx-auto">
            The page you're looking for doesn't exist. But don't worry—our AI can help you turn any thought into design!
          </p>
        </motion.div>

        {/* Search Suggestions */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mb-12"
        >
          <p className="text-[#D3D3D3] mb-6">Maybe you were looking for:</p>
          <div className="flex flex-wrap justify-center gap-3">
            {suggestions.map((suggestion, index) => (
              <motion.button
                key={suggestion}
                className="bg-gray-800/50 text-[#D3D3D3] px-4 py-2 rounded-lg hover:bg-[#C0C0C0] hover:text-[#0B0F19] transition-all duration-300"
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleGoHome}
              >
                {suggestion}
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
        >
          <motion.button
            onClick={handleGoHome}
            className="bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] text-[#0B0F19] px-8 py-4 rounded-xl font-semibold text-lg flex items-center gap-2 hover:shadow-lg transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Home className="w-5 h-5" />
            Go to Homepage
          </motion.button>
          
          <motion.button
            onClick={handleGoBack}
            className="border-2 border-[#C0C0C0] text-[#C0C0C0] px-8 py-4 rounded-xl font-semibold text-lg flex items-center gap-2 hover:bg-[#C0C0C0] hover:text-[#0B0F19] transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft className="w-5 h-5" />
            Go Back
          </motion.button>
        </motion.div>

        {/* Search Box */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.8 }}
          className="max-w-md mx-auto mb-12"
        >
          <div className="relative">
            <input
              type="text"
              placeholder="Search for design tools..."
              className="w-full bg-gray-800/50 border border-gray-700 rounded-xl px-4 py-3 pl-12 text-[#D3D3D3] placeholder-gray-500 focus:border-[#C0C0C0] focus:outline-none transition-colors"
              onKeyPress={(e) => e.key === 'Enter' && handleGoHome()}
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#C0C0C0] opacity-50" />
          </div>
        </motion.div>

        {/* Lotaya AI Branding */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.1, duration: 0.8 }}
          className="border-t border-gray-800 pt-8"
        >
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Sparkles className="w-6 h-6 text-[#C0C0C0]" />
            <span className="text-xl font-bold text-[#C0C0C0]">Lotaya AI</span>
          </div>
          <p className="text-[#D3D3D3] text-sm">
            Turn every thought into design • info@lotaya.io • https://lotaya.io
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default NotFound;