import React from 'react';
import { motion } from 'framer-motion';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { 
  Sparkles, 
  Mail, 
  Phone, 
  MapPin, 
  Globe,
  Facebook,
  Twitter,
  Instagram,
  Linkedin
} from 'lucide-react';

const Footer: React.FC = () => {
  useGSAP(() => {
    gsap.fromTo('.footer-section',
      { y: 50, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, stagger: 0.2, ease: "power3.out" }
    );
  }, []);

  const socialLinks = [
    { icon: Facebook, href: '#', name: 'Facebook' },
    { icon: Twitter, href: '#', name: 'Twitter' },
    { icon: Instagram, href: '#', name: 'Instagram' },
    { icon: Linkedin, href: '#', name: 'LinkedIn' },
  ];

  const quickLinks = [
    { name: 'Logo Generator', href: '#logo-generator' },
    { name: 'Social Media Tools', href: '#social-media' },
    { name: 'Business Templates', href: '#templates' },
    { name: 'Pricing', href: '#pricing' },
    { name: 'About Us', href: '#about' },
    { name: 'Support', href: '#support' },
  ];

  const features = [
    'AI Logo Generation',
    'Social Media Design',
    'Business Templates',
    'Video Content Creation',
    '720p, 1080p, 4K Support',
    'Data Protection',
  ];

  return (
    <footer className="bg-[#0B0F19] border-t border-gray-800 py-16 relative overflow-hidden">
      {/* Background Animation */}
      <div className="absolute inset-0 opacity-5">
        <div className="w-full h-full bg-gradient-to-r from-[#C0C0C0]/10 to-[#D3D3D3]/10" />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          
          {/* Company Info */}
          <motion.div
            className="footer-section lg:col-span-1"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center space-x-2 mb-6">
              <div className="relative">
                <Sparkles className="w-8 h-8 text-[#C0C0C0]" />
                <motion.div
                  className="absolute inset-0"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                >
                  <Sparkles className="w-8 h-8 text-[#D3D3D3] opacity-30" />
                </motion.div>
              </div>
              <span className="text-2xl font-bold text-[#C0C0C0]">Lotaya AI</span>
            </div>

            <p className="text-[#D3D3D3] mb-6 leading-relaxed">
              Turn every thought into design. AI-powered design studio creating professional logos, social media content, and business templates with cutting-edge technology.
            </p>

            {/* Contact Info */}
            <div className="space-y-3">
              <motion.a
                href="mailto:info@lotaya.io"
                className="flex items-center gap-3 text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors group"
                whileHover={{ x: 5 }}
              >
                <Mail className="w-5 h-5 text-[#C0C0C0]" />
                info@lotaya.io
              </motion.a>
              
              <motion.a
                href="tel:09970000616"
                className="flex items-center gap-3 text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors group"
                whileHover={{ x: 5 }}
              >
                <Phone className="w-5 h-5 text-[#C0C0C0]" />
                09970000616
              </motion.a>
              
              <motion.div
                className="flex items-center gap-3 text-[#D3D3D3]"
                whileHover={{ x: 5 }}
              >
                <MapPin className="w-5 h-5 text-[#C0C0C0]" />
                Yangon, Myanmar
              </motion.div>
              
              <motion.a
                href="https://lotaya.io"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors group"
                whileHover={{ x: 5 }}
              >
                <Globe className="w-5 h-5 text-[#C0C0C0]" />
                lotaya.io
              </motion.a>
            </div>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            className="footer-section"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-semibold text-[#C0C0C0] mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <motion.a
                    href={link.href}
                    className="text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors block"
                    whileHover={{ x: 5 }}
                  >
                    {link.name}
                  </motion.a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Features */}
          <motion.div
            className="footer-section"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-semibold text-[#C0C0C0] mb-6">Features</h3>
            <ul className="space-y-3">
              {features.map((feature) => (
                <li key={feature}>
                  <motion.div
                    className="text-[#D3D3D3] flex items-start gap-2"
                    whileHover={{ x: 5 }}
                  >
                    <div className="w-1.5 h-1.5 bg-[#C0C0C0] rounded-full mt-2 flex-shrink-0" />
                    {feature}
                  </motion.div>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Newsletter & Social */}
          <motion.div
            className="footer-section"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-semibold text-[#C0C0C0] mb-6">Stay Connected</h3>
            
            {/* Newsletter Signup */}
            <div className="mb-6">
              <p className="text-[#D3D3D3] mb-4">
                Get updates on new features and design tips
              </p>
              <div className="flex gap-2">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 bg-gray-800/50 border border-gray-700 rounded-lg px-3 py-2 text-[#D3D3D3] placeholder-gray-500 focus:border-[#C0C0C0] focus:outline-none transition-colors text-sm"
                />
                <motion.button
                  className="bg-[#C0C0C0] text-[#0B0F19] px-4 py-2 rounded-lg font-medium hover:bg-[#D3D3D3] transition-colors text-sm"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Subscribe
                </motion.button>
              </div>
            </div>

            {/* Social Links */}
            <div>
              <p className="text-[#D3D3D3] mb-4">Follow us</p>
              <div className="flex gap-3">
                {socialLinks.map((social) => {
                  const Icon = social.icon;
                  return (
                    <motion.a
                      key={social.name}
                      href={social.href}
                      className="bg-gray-800/50 p-3 rounded-lg text-[#D3D3D3] hover:text-[#C0C0C0] hover:bg-gray-700/50 transition-all duration-300"
                      whileHover={{ scale: 1.1, y: -2 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Icon className="w-5 h-5" />
                    </motion.a>
                  );
                })}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Bottom Bar */}
        <motion.div
          className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <p className="text-[#D3D3D3] text-sm text-center md:text-left">
            © 2025 Lotaya AI - Turn every thought into design. All rights reserved. Data protection and privacy guaranteed.
          </p>
          
          <div className="flex flex-wrap gap-6 text-sm">
            <motion.a
              href="#privacy"
              className="text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors"
              whileHover={{ y: -2 }}
            >
              Privacy Policy
            </motion.a>
            <motion.a
              href="#terms"
              className="text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors"
              whileHover={{ y: -2 }}
            >
              Terms of Service
            </motion.a>
            <motion.a
              href="#cookies"
              className="text-[#D3D3D3] hover:text-[#C0C0C0] transition-colors"
              whileHover={{ y: -2 }}
            >
              Cookie Policy
            </motion.a>
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;