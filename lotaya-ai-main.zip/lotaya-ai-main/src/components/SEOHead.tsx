// SEO Head component for dynamic meta tag management
import React, { useEffect } from 'react';
import { seoOptimizer, SEOMetaData } from '../utils/seoOptimizer';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string[];
  ogImage?: string;
  canonicalUrl?: string;
  schemaMarkup?: any;
}

const SEOHead: React.FC<SEOHeadProps> = ({
  title,
  description,
  keywords,
  ogImage,
  canonicalUrl,
  schemaMarkup
}) => {
  useEffect(() => {
    const metaData: Partial<SEOMetaData> = {
      title,
      description,
      keywords,
      ogImage,
      canonicalUrl: canonicalUrl || window.location.href,
      schemaMarkup
    };

    seoOptimizer.updatePageMeta(metaData);
  }, [title, description, keywords, ogImage, canonicalUrl, schemaMarkup]);

  return null; // This component doesn't render anything
};

export default SEOHead;