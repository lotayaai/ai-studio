import React, { useRef, useEffect } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';

const BackgroundAnimation: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    // Create floating particles
    const particles = document.querySelectorAll('.particle');
    
    particles.forEach((particle, index) => {
      gsap.set(particle, {
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        scale: Math.random() * 0.5 + 0.5,
        opacity: Math.random() * 0.5 + 0.2
      });

      gsap.to(particle, {
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        duration: Math.random() * 20 + 10,
        repeat: -1,
        yoyo: true,
        ease: "none"
      });

      gsap.to(particle, {
        rotation: 360,
        duration: Math.random() * 10 + 5,
        repeat: -1,
        ease: "none"
      });
    });

    // Gradient animation
    const gradients = document.querySelectorAll('.gradient-orb');
    gradients.forEach((orb, index) => {
      gsap.to(orb, {
        x: Math.sin(index) * 100,
        y: Math.cos(index) * 100,
        duration: 8 + index * 2,
        repeat: -1,
        yoyo: true,
        ease: "power2.inOut"
      });
    });
  }, []);

  useEffect(() => {
    const handleResize = () => {
      const particles = document.querySelectorAll('.particle');
      particles.forEach((particle) => {
        gsap.set(particle, {
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
        });
      });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div ref={containerRef} className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Gradient Orbs */}
      <div className="gradient-orb absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-[#C0C0C0]/8 to-[#D3D3D3]/8 rounded-full blur-3xl" />
      <div className="gradient-orb absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-to-l from-[#C0C0C0]/12 to-transparent rounded-full blur-3xl" />
      <div className="gradient-orb absolute top-1/2 left-1/2 w-64 h-64 bg-gradient-to-t from-[#D3D3D3]/8 to-transparent rounded-full blur-2xl" />

      {/* Floating Particles */}
      {[...Array(50)].map((_, i) => (
        <div
          key={i}
          className="particle absolute w-1 h-1 bg-[#C0C0C0] rounded-full"
          style={{
            animationDelay: `${Math.random() * 5}s`,
          }}
        />
      ))}

      {/* Grid Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="w-full h-full" style={{
          backgroundImage: `
            linear-gradient(rgba(192, 192, 192, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(192, 192, 192, 0.1) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px'
        }} />
      </div>

      {/* Animated Lines */}
      <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#C0C0C0" stopOpacity="0" />
            <stop offset="50%" stopColor="#C0C0C0" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#C0C0C0" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[...Array(5)].map((_, i) => (
          <line
            key={i}
            x1={`${i * 25}%`}
            y1="0%"
            x2={`${100 - i * 20}%`}
            y2="100%"
            stroke="url(#lineGradient)"
            strokeWidth="1"
            className="animate-pulse"
            style={{ animationDelay: `${i * 0.5}s` }}
          />
        ))}
      </svg>
    </div>
  );
};

export default BackgroundAnimation;