// Google Font Selector Component for Lotaya AI
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Type, Download } from 'lucide-react';
import { useGoogleFonts } from '../hooks/useGoogleApi';
import LoadingSpinner from './LoadingSpinner';

interface GoogleFontSelectorProps {
  onFontSelect: (font: any) => void;
  selectedFont?: string;
  className?: string;
}

const GoogleFontSelector: React.FC<GoogleFontSelectorProps> = ({
  onFontSelect,
  selectedFont,
  className = ''
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('popularity');
  const [filteredFonts, setFilteredFonts] = useState<any[]>([]);
  
  const { fonts, loading, error, fetchFonts } = useGoogleFonts();

  useEffect(() => {
    fetchFonts(sortBy);
  }, [fetchFonts, sortBy]);

  useEffect(() => {
    if (fonts.length > 0) {
      const filtered = fonts.filter(font =>
        font.family.toLowerCase().includes(searchQuery.toLowerCase()) ||
        font.category.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredFonts(filtered.slice(0, 50)); // Limit to 50 fonts for performance
    }
  }, [fonts, searchQuery]);

  const loadFontPreview = (fontFamily: string) => {
    const link = document.createElement('link');
    link.href = `https://fonts.googleapis.com/css2?family=${fontFamily.replace(' ', '+')}:wght@400;500;600;700&display=swap`;
    link.rel = 'stylesheet';
    document.head.appendChild(link);
  };

  const handleFontSelect = (font: any) => {
    loadFontPreview(font.family);
    onFontSelect(font);
  };

  if (loading && fonts.length === 0) {
    return (
      <div className={`bg-gray-900/50 rounded-xl p-6 ${className}`}>
        <LoadingSpinner size="md" message="Loading Google Fonts..." />
      </div>
    );
  }

  return (
    <div className={`bg-gray-900/50 backdrop-blur-lg rounded-xl p-6 border border-gray-800 ${className}`}>
      {/* Header */}
      <div className="flex items-center gap-2 mb-6">
        <Type className="w-6 h-6 text-[#C0C0C0]" />
        <h3 className="text-xl font-semibold text-[#C0C0C0]">Google Fonts</h3>
      </div>

      {/* Search and Sort */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#C0C0C0] opacity-50" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search fonts..."
            className="w-full bg-gray-800/50 border border-gray-700 rounded-lg pl-10 pr-4 py-3 text-[#D3D3D3] placeholder-gray-500 focus:border-[#C0C0C0] focus:outline-none transition-colors"
          />
        </div>
        
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="bg-gray-800/50 border border-gray-700 rounded-lg px-4 py-3 text-[#D3D3D3] focus:border-[#C0C0C0] focus:outline-none transition-colors"
        >
          <option value="popularity">Most Popular</option>
          <option value="alpha">Alphabetical</option>
          <option value="date">Newest</option>
          <option value="trending">Trending</option>
        </select>
      </div>

      {/* Error Display */}
      {error && (
        <div className="mb-6 p-4 bg-red-500/20 border border-red-500/50 rounded-lg">
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      )}

      {/* Font Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-h-96 overflow-y-auto">
        {filteredFonts.map((font, index) => (
          <motion.div
            key={font.family}
            className={`p-4 rounded-lg border cursor-pointer transition-all duration-300 ${
              selectedFont === font.family
                ? 'border-[#C0C0C0] bg-[#C0C0C0]/10'
                : 'border-gray-700 bg-gray-800/30 hover:border-[#C0C0C0]/50 hover:bg-gray-800/50'
            }`}
            onClick={() => handleFontSelect(font)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            {/* Font Preview */}
            <div 
              className="text-lg font-medium text-[#C0C0C0] mb-2"
              style={{ fontFamily: font.family }}
            >
              {font.family}
            </div>
            
            {/* Font Sample Text */}
            <div 
              className="text-sm text-[#D3D3D3] mb-3"
              style={{ fontFamily: font.family }}
            >
              The quick brown fox jumps over the lazy dog
            </div>
            
            {/* Font Info */}
            <div className="flex items-center justify-between text-xs text-[#D3D3D3]">
              <span className="capitalize">{font.category}</span>
              <div className="flex items-center gap-2">
                <span>{font.variants?.length || 0} variants</span>
                {selectedFont === font.family && (
                  <Download className="w-4 h-4 text-[#C0C0C0]" />
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Loading More */}
      {loading && fonts.length > 0 && (
        <div className="mt-4 text-center">
          <LoadingSpinner size="sm" message="Loading more fonts..." />
        </div>
      )}

      {/* No Results */}
      {!loading && filteredFonts.length === 0 && searchQuery && (
        <div className="text-center py-8">
          <Type className="w-12 h-12 text-[#C0C0C0] opacity-50 mx-auto mb-4" />
          <p className="text-[#D3D3D3]">No fonts found matching "{searchQuery}"</p>
        </div>
      )}
    </div>
  );
};

export default GoogleFontSelector;