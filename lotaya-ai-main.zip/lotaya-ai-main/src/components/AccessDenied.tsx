import React from 'react';
import { motion } from 'framer-motion';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { Shield, Home, Mail, Lock, Sparkles } from 'lucide-react';

const AccessDenied: React.FC = () => {
  useGSAP(() => {
    // Animate shield icon
    gsap.fromTo('.shield-icon',
      { scale: 0, rotation: -180 },
      { scale: 1, rotation: 0, duration: 1.2, ease: "back.out(1.7)" }
    );

    // Pulsing animation for lock elements
    gsap.to('.pulse-element', {
      scale: 1.1,
      duration: 2,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut",
      stagger: 0.2
    });

    // Background security pattern animation
    gsap.to('.security-pattern', {
      rotation: 360,
      duration: 20,
      repeat: -1,
      ease: "none"
    });
  }, []);

  const handleGoHome = () => {
    window.location.href = '/';
  };

  const handleContactSupport = () => {
    window.location.href = 'mailto:info@lotaya.io?subject=Access%20Request&body=I%20need%20access%20to%20a%20restricted%20area.';
  };

  return (
    <div className="min-h-screen bg-[#0B0F19] flex items-center justify-center px-4 relative overflow-hidden">
      {/* Background Security Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="security-pattern w-full h-full">
          <svg className="w-full h-full" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="securityGrid" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
                <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#C0C0C0" strokeWidth="0.5"/>
              </pattern>
            </defs>
            <rect width="100" height="100" fill="url(#securityGrid)" />
          </svg>
        </div>
      </div>

      {/* Floating Lock Icons */}
      {[...Array(6)].map((_, i) => (
        <div
          key={i}
          className="pulse-element absolute"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
        >
          <Lock className="w-6 h-6 text-[#C0C0C0] opacity-20" />
        </div>
      ))}

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center max-w-3xl mx-auto relative z-10"
      >
        {/* Shield Icon */}
        <motion.div
          className="shield-icon mb-8"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
        >
          <div className="w-32 h-32 mx-auto bg-red-500/20 rounded-full flex items-center justify-center">
            <Shield className="w-16 h-16 text-red-400" />
          </div>
        </motion.div>

        {/* Error Code */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="mb-8"
        >
          <h1 className="text-8xl sm:text-9xl font-bold text-[#C0C0C0] opacity-20 mb-4">
            403
          </h1>
          <h2 className="text-4xl lg:text-5xl font-bold text-[#C0C0C0] mb-6">
            Access Denied
          </h2>
        </motion.div>

        {/* Main Message */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="mb-12"
        >
          <p className="text-xl text-[#D3D3D3] mb-6 max-w-2xl mx-auto">
            You don't have permission to access this resource. This area is protected to ensure the security and integrity of our AI design platform.
          </p>
          <p className="text-[#D3D3D3] mb-8">
            If you believe this is an error, please contact our support team.
          </p>
        </motion.div>

        {/* Security Features */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12"
        >
          <div className="bg-gray-900/50 backdrop-blur-lg rounded-xl p-6 border border-gray-800">
            <Shield className="w-8 h-8 text-[#C0C0C0] mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-[#C0C0C0] mb-2">
              Data Protection
            </h3>
            <p className="text-[#D3D3D3] text-sm">
              Your designs and data are protected with enterprise-grade security
            </p>
          </div>
          
          <div className="bg-gray-900/50 backdrop-blur-lg rounded-xl p-6 border border-gray-800">
            <Lock className="w-8 h-8 text-[#C0C0C0] mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-[#C0C0C0] mb-2">
              Secure Access
            </h3>
            <p className="text-[#D3D3D3] text-sm">
              Role-based permissions ensure only authorized users can access resources
            </p>
          </div>
          
          <div className="bg-gray-900/50 backdrop-blur-lg rounded-xl p-6 border border-gray-800">
            <Sparkles className="w-8 h-8 text-[#C0C0C0] mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-[#C0C0C0] mb-2">
              AI Privacy
            </h3>
            <p className="text-[#D3D3D3] text-sm">
              Your creative process and AI interactions remain completely private
            </p>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
        >
          <motion.button
            onClick={handleGoHome}
            className="bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] text-[#0B0F19] px-8 py-4 rounded-xl font-semibold text-lg flex items-center gap-2 hover:shadow-lg transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Home className="w-5 h-5" />
            Return to Homepage
          </motion.button>
          
          <motion.button
            onClick={handleContactSupport}
            className="border-2 border-[#C0C0C0] text-[#C0C0C0] px-8 py-4 rounded-xl font-semibold text-lg flex items-center gap-2 hover:bg-[#C0C0C0] hover:text-[#0B0F19] transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Mail className="w-5 h-5" />
            Contact Support
          </motion.button>
        </motion.div>

        {/* Contact Information */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="bg-gray-900/30 backdrop-blur-lg rounded-xl p-6 border border-gray-800 mb-8"
        >
          <h3 className="text-lg font-semibold text-[#C0C0C0] mb-4">
            Need Access? Contact Us
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[#D3D3D3]">
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#C0C0C0]" />
              <span>info@lotaya.io</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 text-[#C0C0C0]">📞</span>
              <span>09970000616</span>
            </div>
          </div>
        </motion.div>

        {/* Lotaya AI Branding */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.8 }}
          className="border-t border-gray-800 pt-8"
        >
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Sparkles className="w-6 h-6 text-[#C0C0C0]" />
            <span className="text-xl font-bold text-[#C0C0C0]">Lotaya AI</span>
          </div>
          <p className="text-[#D3D3D3] text-sm">
            Turn every thought into design • Secure • Private • Professional
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default AccessDenied;