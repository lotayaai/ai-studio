// Image Analyzer Component using Google Vision API
import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Upload, Eye, Palette, Tag, FileText } from 'lucide-react';
import { useGoogleVision } from '../hooks/useGoogleApi';
import LoadingSpinner from './LoadingSpinner';

interface ImageAnalyzerProps {
  onAnalysisComplete?: (analysis: any) => void;
  className?: string;
}

const ImageAnalyzer: React.FC<ImageAnalyzerProps> = ({
  onAnalysisComplete,
  className = ''
}) => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [analysisResults, setAnalysisResults] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { analysis, loading, error, analyzeImage, detectText } = useGoogleVision();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedImage) return;

    try {
      const results = await analyzeImage(selectedImage);
      setAnalysisResults(results);
      
      if (onAnalysisComplete) {
        onAnalysisComplete(results);
      }
    } catch (err) {
      console.error('Analysis failed:', err);
    }
  };

  const handleTextDetection = async () => {
    if (!selectedImage) return;

    try {
      const detectedText = await detectText(selectedImage);
      setAnalysisResults(prev => ({
        ...prev,
        detectedText
      }));
    } catch (err) {
      console.error('Text detection failed:', err);
    }
  };

  const getLabels = () => {
    return analysisResults?.responses?.[0]?.labelAnnotations || [];
  };

  const getColors = () => {
    return analysisResults?.responses?.[0]?.imagePropertiesAnnotation?.dominantColors?.colors || [];
  };

  const getDetectedText = () => {
    return analysisResults?.detectedText || 
           analysisResults?.responses?.[0]?.textAnnotations?.[0]?.description || '';
  };

  return (
    <div className={`bg-gray-900/50 backdrop-blur-lg rounded-xl p-6 border border-gray-800 ${className}`}>
      {/* Header */}
      <div className="flex items-center gap-2 mb-6">
        <Eye className="w-6 h-6 text-[#C0C0C0]" />
        <h3 className="text-xl font-semibold text-[#C0C0C0]">AI Image Analyzer</h3>
      </div>

      {/* File Upload */}
      <div className="mb-6">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />
        
        <motion.div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-gray-700 rounded-xl p-8 text-center cursor-pointer hover:border-[#C0C0C0]/50 transition-colors"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          {imagePreview ? (
            <div className="space-y-4">
              <img
                src={imagePreview}
                alt="Preview"
                className="max-w-full max-h-48 mx-auto rounded-lg"
              />
              <p className="text-[#D3D3D3]">Click to change image</p>
            </div>
          ) : (
            <div className="space-y-4">
              <Upload className="w-12 h-12 text-[#C0C0C0] mx-auto" />
              <div>
                <p className="text-[#C0C0C0] font-medium">Upload an image to analyze</p>
                <p className="text-[#D3D3D3] text-sm">Supports JPG, PNG, GIF up to 10MB</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Analysis Buttons */}
      {selectedImage && (
        <div className="flex flex-wrap gap-3 mb-6">
          <motion.button
            onClick={handleAnalyze}
            disabled={loading}
            className="flex items-center gap-2 bg-[#C0C0C0] text-[#0B0F19] px-4 py-2 rounded-lg font-medium hover:bg-[#D3D3D3] transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {loading ? <LoadingSpinner size="sm" message="" /> : <Eye className="w-4 h-4" />}
            Analyze Image
          </motion.button>
          
          <motion.button
            onClick={handleTextDetection}
            disabled={loading}
            className="flex items-center gap-2 bg-gray-800 text-[#D3D3D3] px-4 py-2 rounded-lg font-medium hover:bg-gray-700 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FileText className="w-4 h-4" />
            Detect Text
          </motion.button>
        </div>
      )}

      {/* Error Display */}
      {error && (
        <div className="mb-6 p-4 bg-red-500/20 border border-red-500/50 rounded-lg">
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      )}

      {/* Analysis Results */}
      {analysisResults && (
        <div className="space-y-6">
          {/* Labels */}
          {getLabels().length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Tag className="w-5 h-5 text-[#C0C0C0]" />
                <h4 className="text-lg font-semibold text-[#C0C0C0]">Detected Objects</h4>
              </div>
              <div className="flex flex-wrap gap-2">
                {getLabels().slice(0, 10).map((label: any, index: number) => (
                  <span
                    key={index}
                    className="bg-gray-800/50 text-[#D3D3D3] px-3 py-1 rounded-full text-sm"
                  >
                    {label.description} ({Math.round(label.score * 100)}%)
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Colors */}
          {getColors().length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Palette className="w-5 h-5 text-[#C0C0C0]" />
                <h4 className="text-lg font-semibold text-[#C0C0C0]">Dominant Colors</h4>
              </div>
              <div className="flex flex-wrap gap-3">
                {getColors().slice(0, 8).map((colorInfo: any, index: number) => {
                  const color = colorInfo.color;
                  const rgb = `rgb(${color.red || 0}, ${color.green || 0}, ${color.blue || 0})`;
                  return (
                    <div key={index} className="flex items-center gap-2">
                      <div
                        className="w-8 h-8 rounded-full border-2 border-gray-600"
                        style={{ backgroundColor: rgb }}
                      />
                      <span className="text-[#D3D3D3] text-sm">
                        {Math.round(colorInfo.score * 100)}%
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Detected Text */}
          {getDetectedText() && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <FileText className="w-5 h-5 text-[#C0C0C0]" />
                <h4 className="text-lg font-semibold text-[#C0C0C0]">Detected Text</h4>
              </div>
              <div className="bg-gray-800/50 rounded-lg p-4">
                <p className="text-[#D3D3D3] whitespace-pre-wrap">
                  {getDetectedText()}
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ImageAnalyzer;