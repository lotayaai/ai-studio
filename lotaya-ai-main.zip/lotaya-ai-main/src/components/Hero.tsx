import React from 'react';
import { motion } from 'framer-motion';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { ArrowRight, Sparkles, Zap, Palette } from 'lucide-react';
import BackgroundAnimation from './BackgroundAnimation';

const Hero: React.FC = () => {
  useGSAP(() => {
    const tl = gsap.timeline();
    
    tl.fromTo('.hero-title',
      { y: 100, opacity: 0 },
      { y: 0, opacity: 1, duration: 1.2, ease: "power3.out" }
    )
    .fromTo('.hero-subtitle',
      { y: 50, opacity: 0 },
      { y: 0, opacity: 1, duration: 1, ease: "power3.out" },
      "-=0.8"
    )
    .fromTo('.hero-cta',
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: "power3.out" },
      "-=0.6"
    )
    .fromTo('.hero-features',
      { y: 20, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, stagger: 0.2, ease: "power3.out" },
      "-=0.4"
    );

    // Floating animation for feature cards
    gsap.to('.floating-card', {
      y: -10,
      duration: 2,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut",
      stagger: 0.3
    });
  }, []);

  const features = [
    { icon: Sparkles, title: "AI-Powered", description: "Advanced AI creates unique designs" },
    { icon: Zap, title: "Lightning Fast", description: "Generate designs in seconds" },
    { icon: Palette, title: "Professional", description: "Production-ready quality" }
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#0B0F19]">
      <BackgroundAnimation />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-5xl mx-auto">
          {/* Main Title */}
          <motion.h1 
            className="hero-title text-4xl sm:text-5xl lg:text-7xl font-bold text-[#C0C0C0] mb-6 leading-tight"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            Turn Every Thought
            <br />
            <span className="bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] bg-clip-text text-transparent">
              Into Design
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p 
            className="hero-subtitle text-lg sm:text-xl text-[#D3D3D3] mb-8 max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            Transform your ideas into professional logos, social media content, and business templates using cutting-edge AI technology. From concept to creation in seconds.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div 
            className="hero-cta flex flex-col sm:flex-row gap-4 justify-center items-center mb-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <motion.button
              className="bg-gradient-to-r from-[#C0C0C0] to-[#D3D3D3] text-[#0B0F19] px-8 py-4 rounded-xl font-semibold text-lg flex items-center gap-2 hover:shadow-2xl transition-all duration-300 group"
              whileHover={{ 
                scale: 1.05, 
                boxShadow: "0 20px 40px rgba(192, 192, 192, 0.3)" 
              }}
              whileTap={{ scale: 0.95 }}
            >
              Start Creating
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>
            
            <motion.button
              className="border-2 border-[#C0C0C0] text-[#C0C0C0] px-8 py-4 rounded-xl font-semibold text-lg hover:bg-[#C0C0C0] hover:text-[#0B0F19] transition-all duration-300"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Watch Demo
            </motion.button>
          </motion.div>

          {/* Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  className="hero-features floating-card bg-gray-900/40 backdrop-blur-lg border border-gray-800 rounded-2xl p-6 hover:border-[#C0C0C0]/50 transition-all duration-300 hover:bg-gray-900/60"
                  whileHover={{ 
                    scale: 1.05,
                    backgroundColor: "rgba(192, 192, 192, 0.05)" 
                  }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="text-[#C0C0C0] mb-4 flex justify-center">
                    <Icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-[#C0C0C0] mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-[#D3D3D3]">
                    {feature.description}
                  </p>
                </motion.div>
              );
            })}
          </div>

          {/* Company Info */}
          <motion.div
            className="mt-16 pt-8 border-t border-gray-800"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
          >
            <p className="text-[#D3D3D3] text-sm">
              Lotaya AI - Turn every thought into design • Yangon, Myanmar • info@lotaya.io • https://lotaya.io
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;